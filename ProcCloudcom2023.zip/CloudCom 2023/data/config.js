var config = {
	"proceeding": {
		"acronym": "CloudCom",
		"year": 2023
	},
	"bannerFile": "content/images/CloudCom_2023_banner.jpg",
	"enableGDPR": false,
	"enableAffiliationIndex": false,
	"videoPlayer": "mediaelement",
	"webpubDownload": {
		"enabled": null,
		"location": "pdfs/CloudCom 2023.zip"
	},
	"services": {
		"authEnabled": false,
		"trackingEnabled": false
	}
};
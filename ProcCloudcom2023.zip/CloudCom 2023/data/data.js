var webpub = {data: {
	"conferences": [
		{
			"title": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom)",
			"acronym": "CloudCom",
			"year": 2023,
			"frontMatter": [
				{
					"class": "FM",
					"type": "FM_TITLE_PAGE_I",
					"text": "Title Page i",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z001/398200z001.pdf",
					"extraLocations": [],
					"pageNumber": 1,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_TITLE_PAGE_III",
					"text": "Title Page iii",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z003/398200z003.pdf",
					"extraLocations": [],
					"pageNumber": 3,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_COPYRIGHT_PAGE",
					"text": "Copyright Page",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z004/398200z004.pdf",
					"extraLocations": [],
					"pageNumber": 4,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_TABLE_OF_CONTENTS",
					"text": "Table of Contents",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z005/398200z005.pdf",
					"extraLocations": [],
					"pageNumber": 5,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_MESSAGE_GENERAL_CHAIR",
					"text": "Message from General Co-Chairs",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z011/398200z011.pdf",
					"extraLocations": [],
					"pageNumber": 11,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_MESSAGE_CONFERENCE_CHAIR",
					"text": "Message from Program Chairs",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z012/398200z012.pdf",
					"extraLocations": [],
					"pageNumber": 12,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_MESSAGE_SYMPOSIUM_CHAIR",
					"text": "Message from SCC Workshop Chairs",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z013/398200z013.pdf",
					"extraLocations": [],
					"pageNumber": 13,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_MESSAGE_GENERAL_CHAIR",
					"text": "Message from IaC Workshop Chairs",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z014/398200z014.pdf",
					"extraLocations": [],
					"pageNumber": 14,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_LON_COMMITTEE_LISTS",
					"text": "Organizing Committee",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z015/398200z015.pdf",
					"extraLocations": [],
					"pageNumber": 15,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_LON_COMMITTEE_LISTS",
					"text": "Program Committee",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z016/398200z016.pdf",
					"extraLocations": [],
					"pageNumber": 16,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_LON_COMMITTEE_LISTS",
					"text": "Steering Committee",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z019/398200z019.pdf",
					"extraLocations": [],
					"pageNumber": 19,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_LON_COMMITTEE_LISTS",
					"text": "SCC Workshop Committee",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z020/398200z020.pdf",
					"extraLocations": [],
					"pageNumber": 20,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_LON_COMMITTEE_LISTS",
					"text": "IAC Workshop Committee",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z021/398200z021.pdf",
					"extraLocations": [],
					"pageNumber": 21,
					"isPageNumberRoman": true
				},
				{
					"class": "FM",
					"type": "FM_LON_COMMITTEE_LISTS",
					"text": "Reviewers",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200z022/398200z022.pdf",
					"extraLocations": [],
					"pageNumber": 22,
					"isPageNumberRoman": true
				}
			],
			"backMatter": [
				{
					"class": "BM",
					"type": "BM_AUTHOR_INDEX",
					"text": "Author Index",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a351/398200a351.pdf",
					"extraLocations": [],
					"pageNumber": 351,
					"isPageNumberRoman": false
				}
			],
			"sections": [
				{
					"class": "SD",
					"type": "SD_SESSION",
					"title": "Main Conference",
					"lineItems": [
						{
							"eid": "38cEvqIZLojyrX0wnFq8Gh",
							"type": "authorPaper",
							"text": "Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a001/398200a001.pdf",
							"extraLocations": [],
							"authorNames": "Hend K. Gedawy (Carnegie Mellon University), Khaled A. Harras (Carnegie Mellon University), Temoor Tanveer (Carnegie Mellon University), Thang Bui (Carnegie Mellon University)",
							"abstract": "Federated Learning is being hailed as a privacy-preserving machine learning alternative, by allowing models to be distributively trained on source devices owning their data. Most FL solutions, and their assessments, however, assume superior environmental reliability, despite the more realistic variances in environmental factors such as device and network capacity, data distribution, and device churn. As such, we argue in this paper, that there is a growing chasm between current FL assessment setups and the evolving FL assessment needs. Motivated by this chasm, we conduct, to the best of our knowledge, the first empirical measurement study of FL performance given realistic environmental factors. Our study quantifies the impact of these environmental factors on FL performance in terms of training time, accuracy, and communication overhead. Our findings have broad implications for the future development of FL including client admission control and scheduling optimizations.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study 1697736326683 10.1109/CloudCom59040.2023.00015 Hend K. Gedawy Carnegie Mellon University hkg@andrew.cmu.edu Khaled A. Harras Carnegie Mellon University kharras@cs.cmu.edu Temoor Tanveer Carnegie Mellon University ttanveer@andrew.cmu.edu Thang Bui Carnegie Mellon University tnbui@andrew.cmu.edu Measurements Federated Learning Systems Edge Computing Internet of Things Federated Learning is being hailed as a privacy-preserving machine learning alternative, by allowing models to be distributively trained on source devices owning their data. Most FL solutions, and their assessments, however, assume superior environmental reliability, despite the more realistic variances in environmental factors such as device and network capacity, data distribution, and device churn. As such, we argue in this paper, that there is a growing chasm between current FL assessment setups and the evolving FL assessment needs. Motivated by this chasm, we conduct, to the best of our knowledge, the first empirical measurement study of FL performance given realistic environmental factors. Our study quantifies the impact of these environmental factors on FL performance in terms of training time, accuracy, and communication overhead. Our findings have broad implications for the future development of FL including client admission control and scheduling optimizations.",
							"pageNumber": 1,
							"isPageNumberRoman": false
						},
						{
							"eid": "3Jh4PSqPKlkornpwQwPIrT",
							"type": "authorPaper",
							"text": "SAGE - A Tool for Optimal Deployments in Kubernetes Clusters",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a010/398200a010.pdf",
							"extraLocations": [],
							"authorNames": "Vlad-Ioan Luca (West University of Timisoara, Romania), M\u0103d\u0103lina Era\u015Fcu (West University of Timisoara, Romania)",
							"abstract": "Cloud computing has brought a fundamental transformation in how organizations operate their applications, enabling them to achieve affordable high availability of services. Kubernetes has emerged as the preferred choice for container orchestration and service management across many Cloud computing platforms. The scheduler in Kubernetes plays a crucial role in determining the placement of newly deployed service containers. However, the default scheduler, while fast, often lacks optimization, leading to inefficient service placement or even deployment failures. This paper introduces SAGE, a tool for optimal deployment plans in Kubernetes clusters that can also assist the Kubernetes default scheduler and any other custom scheduler in application deployment. SAGE computes an optimal deployment plan by fulfilling the constraints of the application to be deployed and by taking into consideration the available Cloud resources with the aim of minimizing the infrastructure rental cost. We show the potential benefits of using SAGE by considering test cases with various characteristics. It turns out that SAGE surpasses schedulers by comprehensively analyzing the application demand and cluster image. This ability allows it to better understand the needs of the pods, resulting in consistently optimal solutions across all test scenarios. The accompanying material of this paper is publicly available at https://github.com/SAGE-Project/SAGE-Predeployer.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 SAGE - A Tool for Optimal Deployments in Kubernetes Clusters 1697274552976 10.1109/CloudCom59040.2023.00016 Vlad-Ioan Luca West University of Timisoara, Romania ioan.luca99@e-uvt.ro M\u0103d\u0103lina Era\u015Fcu West University of Timisoara, Romania madalina.erascu@e-uvt.ro Cloud Services deployment scheduler Kubernetes optimization Cloud computing has brought a fundamental transformation in how organizations operate their applications, enabling them to achieve affordable high availability of services. Kubernetes has emerged as the preferred choice for container orchestration and service management across many Cloud computing platforms. The scheduler in Kubernetes plays a crucial role in determining the placement of newly deployed service containers. However, the default scheduler, while fast, often lacks optimization, leading to inefficient service placement or even deployment failures. This paper introduces SAGE, a tool for optimal deployment plans in Kubernetes clusters that can also assist the Kubernetes default scheduler and any other custom scheduler in application deployment. SAGE computes an optimal deployment plan by fulfilling the constraints of the application to be deployed and by taking into consideration the available Cloud resources with the aim of minimizing the infrastructure rental cost. We show the potential benefits of using SAGE by considering test cases with various characteristics. It turns out that SAGE surpasses schedulers by comprehensively analyzing the application demand and cluster image. This ability allows it to better understand the needs of the pods, resulting in consistently optimal solutions across all test scenarios. The accompanying material of this paper is publicly available at https://github.com/SAGE-Project/SAGE-Predeployer.",
							"pageNumber": 10,
							"isPageNumberRoman": false
						},
						{
							"eid": "QPR3udM38mRHjUVfpZCA8",
							"type": "authorPaper",
							"text": "Introducing TinyKVM for High-Performance CDN Edge Services",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a018/398200a018.pdf",
							"extraLocations": [],
							"authorNames": "Alf-Andr\u00E9 Walla (University of Oslo (UiO), Norway), Paal E. Engelstad (University of Oslo (UiO), Norway)",
							"abstract": "On the Internet today, Content Delivery Networks (CDNs) are widely used to increase performance and reduce latency, by spreading the workload over CDN Edge Servers that are located as close as possible to the users. Content is stored in HTTP caches at the edge servers, and requests might be load-balanced over several replicated edge servers in order to try to handle requests closer to users. In this way, bottlenecks are avoided and communication latency is reduced. The caches can often run on the bare metal to achieve native performance, or in Docker. However, there is also a trend towards sandboxing, due to the demand for customer separation (multi-tenancy) and for security reasons, even though sandboxing will often reduce performance and increase latencies. In order to address these two sets of conflicting goals, this paper presents a novel modern specialized VM, referred to as \"TinyKVM\", for the purposes of computation on CDN edge servers. It is designed for low overhead, minimal footprint and close-to-native compute performance. The paper demonstrates that HTTP caching - and other services - on Edge servers can provide sandboxing using hardware virtualization, without having to compromise much in terms of performance and overheads. This paper describes the architecture of \"TinyKVM\", as well as the usability and performance of the TinyKVM implementation, using well-known benchmarks to demonstrate that it has native performance with no overhead and very low fixed overheads.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Introducing TinyKVM for High-Performance CDN Edge Services 1697026292974 10.1109/CloudCom59040.2023.00017 Alf-Andr\u00E9 Walla University of Oslo (UiO), Norway alf@varnish-software.com Paal E. Engelstad University of Oslo (UiO), Norway paal.engelstad@its.uio.no cloud computing edge computing sandboxing hardware virtualization kvm On the Internet today, Content Delivery Networks (CDNs) are widely used to increase performance and reduce latency, by spreading the workload over CDN Edge Servers that are located as close as possible to the users. Content is stored in HTTP caches at the edge servers, and requests might be load-balanced over several replicated edge servers in order to try to handle requests closer to users. In this way, bottlenecks are avoided and communication latency is reduced. The caches can often run on the bare metal to achieve native performance, or in Docker. However, there is also a trend towards sandboxing, due to the demand for customer separation (multi-tenancy) and for security reasons, even though sandboxing will often reduce performance and increase latencies. In order to address these two sets of conflicting goals, this paper presents a novel modern specialized VM, referred to as \"TinyKVM\", for the purposes of computation on CDN edge servers. It is designed for low overhead, minimal footprint and close-to-native compute performance. The paper demonstrates that HTTP caching - and other services - on Edge servers can provide sandboxing using hardware virtualization, without having to compromise much in terms of performance and overheads. This paper describes the architecture of \"TinyKVM\", as well as the usability and performance of the TinyKVM implementation, using well-known benchmarks to demonstrate that it has native performance with no overhead and very low fixed overheads.",
							"pageNumber": 18,
							"isPageNumberRoman": false
						},
						{
							"eid": "2ppuQgLvVHgCO1Ig94FOnV",
							"type": "authorPaper",
							"text": "Inverse Response Time Ratio Scheduler: Optimizing Throughput and Response Time for Serverless Computing",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a026/398200a026.pdf",
							"extraLocations": [],
							"authorNames": "Mina Morcos (Boston University), Ibrahim Matta (Boston University)",
							"abstract": "We explore the problem of scheduling in a distributed multi-cloud serverless scenario, in the case where requests to function instances contend over the same resources. For this case, we present an efficient scheduling algorithm that leverages function profiling to detect resource contention, and improves the response time of requests, as well as the overall completion time of all requests. We compare our work to other schedulers such as a simple random scheduler, a simple round-robin scheduler, and schedulers that either load balance requests for each function across clouds, choose the cloud with the best profile, or select the cloud with the most available resources. Besides simulations, we have created a simple experiment of our scheduler running against two OpenWhisk serverless instances over the FABRIC testbed. We show that our inverse response time ratio scheduling algorithm can yield an improvement in average response time of around 32% over the best of the other schedulers when the execution time of a function on a given cloud is twice as much as on another. We also show that the improvement increases as the dispersion of the execution time across the distributed environment increases.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Inverse Response Time Ratio Scheduler: Optimizing Throughput and Response Time for Serverless Computing 1697661883953 10.1109/CloudCom59040.2023.00018 Mina Morcos Boston University minawm@bu.edu Ibrahim Matta Boston University matta@bu.edu Scheduling Serverless Cloud Computing Performance Analysis Testbed Evaluation We explore the problem of scheduling in a distributed multi-cloud serverless scenario, in the case where requests to function instances contend over the same resources. For this case, we present an efficient scheduling algorithm that leverages function profiling to detect resource contention, and improves the response time of requests, as well as the overall completion time of all requests. We compare our work to other schedulers such as a simple random scheduler, a simple round-robin scheduler, and schedulers that either load balance requests for each function across clouds, choose the cloud with the best profile, or select the cloud with the most available resources. Besides simulations, we have created a simple experiment of our scheduler running against two OpenWhisk serverless instances over the FABRIC testbed. We show that our inverse response time ratio scheduling algorithm can yield an improvement in average response time of around 32% over the best of the other schedulers when the execution time of a function on a given cloud is twice as much as on another. We also show that the improvement increases as the dispersion of the execution time across the distributed environment increases.",
							"pageNumber": 26,
							"isPageNumberRoman": false
						},
						{
							"eid": "6yKsrKBRk8UzCsRKT1sb76",
							"type": "authorPaper",
							"text": "GSLAC: GPU Software Level Access Control for Information Isolation on Cloud Platforms",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a034/398200a034.pdf",
							"extraLocations": [],
							"authorNames": "Chia-Chang Li (National Tsing Hua University, Taiwan), Po-Cheng Wu (National Tsing Hua University, Taiwan), Che-Rung Lee (National Tsing Hua University, Taiwan)",
							"abstract": "The massive parallel architecture makes Graphics Processing Unit (GPU) a powerful accelerator for various computational intensive tasks, such as computer games, scientific computation, cryptocurrency, and AI model training and inferences. In many cloud platforms, GPUs are scarce computing resources and shared by multiple users. To achieve information isolation among different user programs, GPU access control is an essential technology to prevent the information leaking for program execution and data access when using GPUs. However, the lack of a zeroing mechanism in GPUs, combined with vulnerabilities in user-land drivers, poses risks to both data confidentiality and system integrity. In this paper, we propose a novel system architecture, called GSLAC, to provide GPU System Level Access Control for information isolation on cloud platforms. GSLAC combines resource isolation and mandatory access control measures with the aim of establishing a secure computing environment. It encompasses an authentication mechanism for authorized GPU access, as well as the integration of mandatory access control mechanisms to safeguard sensitive resources. Furthermore, with a careful design, user programs can be compiled and executed as they do in a normal environment without sacrifying the desired performance.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 GSLAC: GPU Software Level Access Control for Information Isolation on Cloud Platforms 1697455074575 10.1109/CloudCom59040.2023.00019 Chia-Chang Li National Tsing Hua University, Taiwan hmtp42563@gmail.com Po-Cheng Wu National Tsing Hua University, Taiwan b06902037@ntu.edu.tw Che-Rung Lee National Tsing Hua University, Taiwan cherung@cs.nthu.edu.tw Virtualization GPU Access Control The massive parallel architecture makes Graphics Processing Unit (GPU) a powerful accelerator for various computational intensive tasks, such as computer games, scientific computation, cryptocurrency, and AI model training and inferences. In many cloud platforms, GPUs are scarce computing resources and shared by multiple users. To achieve information isolation among different user programs, GPU access control is an essential technology to prevent the information leaking for program execution and data access when using GPUs. However, the lack of a zeroing mechanism in GPUs, combined with vulnerabilities in user-land drivers, poses risks to both data confidentiality and system integrity. In this paper, we propose a novel system architecture, called GSLAC, to provide GPU System Level Access Control for information isolation on cloud platforms. GSLAC combines resource isolation and mandatory access control measures with the aim of establishing a secure computing environment. It encompasses an authentication mechanism for authorized GPU access, as well as the integration of mandatory access control mechanisms to safeguard sensitive resources. Furthermore, with a careful design, user programs can be compiled and executed as they do in a normal environment without sacrifying the desired performance.",
							"pageNumber": 34,
							"isPageNumberRoman": false
						},
						{
							"eid": "7v6jiPkWCVkjcrjWYoa3wh",
							"type": "authorPaper",
							"text": "A Load Balancing Algorithm For Long-Life Green Edge Systems",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a042/398200a042.pdf",
							"extraLocations": [],
							"authorNames": "Roberto Beraldi (Sapienza University of Rome, Italy), Gabriele Proietti Mattia (Sapienza University of Rome, Italy)",
							"abstract": "We consider the case of a set of energy harvesting edge nodes, equipped with photovoltaic panels that implement some kind of monitoring service. To ensure that the service operates in an optimal way, nodes have sometimes offload some of their data to other nodes. We show that this kind of task offloading (migration) can improve service performance by avoiding temporary interruptions and prolonging the overall service lifetime. We present a centralized algorithm based on Linear Programming optimization problem solution and a distributed implementation.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 A Load Balancing Algorithm For Long-Life Green Edge Systems 1696933165878 10.1109/CloudCom59040.2023.00020 Roberto Beraldi Sapienza University of Rome, Italy n/a Gabriele Proietti Mattia Sapienza University of Rome, Italy n/a Green Edge Computing Load Balancing Lifespan Decentralization We consider the case of a set of energy harvesting edge nodes, equipped with photovoltaic panels that implement some kind of monitoring service. To ensure that the service operates in an optimal way, nodes have sometimes offload some of their data to other nodes. We show that this kind of task offloading (migration) can improve service performance by avoiding temporary interruptions and prolonging the overall service lifetime. We present a centralized algorithm based on Linear Programming optimization problem solution and a distributed implementation.",
							"pageNumber": 42,
							"isPageNumberRoman": false
						},
						{
							"eid": "2RqCQijkBGOOgtbf8dSQAL",
							"type": "authorPaper",
							"text": "Enhancing Mobile Privacy and Security: A Face Skin Patch-Based Anti-Spoofing Approach",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a052/398200a052.pdf",
							"extraLocations": [],
							"authorNames": "Qiushi Guo (AI Lab, China Merchants Bank), Yifan Chen (AI Lab, China Merchants Bank), Shisha Liao (AI Lab, China Merchants Bank)",
							"abstract": "As Facial Recognition System(FRS) is widely applied in areas such as access control and mobile payments due to its convenience and high accuracy. The security of facial recognition is also highly regarded. The Face anti-spoofing system(FAS) for face recognition is an important component used to enhance the security of face recognition systems. Traditional FAS used images containing identity information to detect spoofing traces, however there is a risk of privacy leakage during the transmission and storage of these images. Besides, the encryption and decryption of these privacy-sensitive data takes too long compared to inference time by FAS model. To address the above issues, we propose a face anti-spoofing algorithm based on facial skin patches leveraging pure facial skin patch images as input, which contain no privacy information, no encryption or decryption is needed for these images. We conduct experiments on several public datasets, the results prove that our algorithm has demonstrated superiority in both accuracy and speed. ",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Enhancing Mobile Privacy and Security: A Face Skin Patch-Based Anti-Spoofing Approach 1697111123401 10.1109/CloudCom59040.2023.00021 Qiushi Guo AI Lab, China Merchants Bank guoqiushi910@cmbchina.com Yifan Chen AI Lab, China Merchants Bank stormand@cmbchina.com Shisha Liao AI Lab, China Merchants Bank liaoss@cmbchina.com As Facial Recognition System(FRS) is widely applied in areas such as access control and mobile payments due to its convenience and high accuracy. The security of facial recognition is also highly regarded. The Face anti-spoofing system(FAS) for face recognition is an important component used to enhance the security of face recognition systems. Traditional FAS used images containing identity information to detect spoofing traces, however there is a risk of privacy leakage during the transmission and storage of these images. Besides, the encryption and decryption of these privacy-sensitive data takes too long compared to inference time by FAS model. To address the above issues, we propose a face anti-spoofing algorithm based on facial skin patches leveraging pure facial skin patch images as input, which contain no privacy information, no encryption or decryption is needed for these images. We conduct experiments on several public datasets, the results prove that our algorithm has demonstrated superiority in both accuracy and speed.",
							"pageNumber": 52,
							"isPageNumberRoman": false
						},
						{
							"eid": "2oHTijBlUlBvHHAxRS5izd",
							"type": "authorPaper",
							"text": "A Blockchain-Based Online Trading Platform: TrustTrade",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a058/398200a058.pdf",
							"extraLocations": [],
							"authorNames": "Guang Yang (Western Norway University of Applied Sciences, Norway), Lorena-Alina Alexandru (Western Norway University of Applied Sciences, Norway), Marius Storheim (Western Norway University of Applied Sciences, Norway)",
							"abstract": "In addition to general concerns about user privacy and data ownership, the primary security issues for online marketplaces are scam and fraud activities that potentially can violate both buyers and sellers. In this work, we study blockchain implementation in an online marketplace platform: TrustTrade, to overcome these security issues. We mainly investigate how to utilize blockchain's innovation properties: decentralization, anonymity, and audibility to facilitate a consumer-to-consumer online marketplace to provide a reliable trading ecosystem where people can securely interact, share information, and engage in transactions, yet address other security concerns, including ownership of data and privacy.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 A Blockchain-Based Online Trading Platform: TrustTrade 1697537545648 10.1109/CloudCom59040.2023.00022 Guang Yang Western Norway University of Applied Sciences, Norway Guang.Yang@hvl.no Lorena-Alina Alexandru Western Norway University of Applied Sciences, Norway lorenaalexandru23@gmail.com Marius Storheim Western Norway University of Applied Sciences, Norway Marius@storheim.biz Blockchain Smart Contract Online Trading Platform Decentralized Marketplace C2C Network Ethereum In addition to general concerns about user privacy and data ownership, the primary security issues for online marketplaces are scam and fraud activities that potentially can violate both buyers and sellers. In this work, we study blockchain implementation in an online marketplace platform: TrustTrade, to overcome these security issues. We mainly investigate how to utilize blockchain's innovation properties: decentralization, anonymity, and audibility to facilitate a consumer-to-consumer online marketplace to provide a reliable trading ecosystem where people can securely interact, share information, and engage in transactions, yet address other security concerns, including ownership of data and privacy.",
							"pageNumber": 58,
							"isPageNumberRoman": false
						},
						{
							"eid": "15WZ5iTaAi2WQ3FWCUeQ7u",
							"type": "authorPaper",
							"text": "Enabling 5G QoS Configuration Capabilities for IoT Applications on Container Orchestration Platform",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a063/398200a063.pdf",
							"extraLocations": [],
							"authorNames": "Yu Liu (Ericsson Research, Sweden), Aitor Hernandez Herranz (Ericsson Research, Sweden)",
							"abstract": "Container orchestration platform is the foundation of modern cloud infrastructure. In recent years, container orchestration platform has been evolving to cross the boundary of device, edge, and cloud. More and more Internet of Things (IoT) applications such as robotics and eXtended Reality (XR) have been deployed across the device-cloud continuum through the container orchestration platform, e.g., the Kubernetes (K8s) framework. Meanwhile, the rapid expansion of advanced communication technologies like 5G has endorsed the revolution in IoT applications as more network resource is available for critical IoT use cases. This paper aims to integrate network configuration capabilities provided by a 5G Network Exposure Function (NEF) into the K8s framework which is used to simplify application deployment in an orchestration in the device-cloud continuum. Specifically, a Linux fwmark-based network Quality of Service (QoS) configuration method is proposed to expose the QoS information from an overlay network that is used by the container orchestration platform to the underlay network. A Container Networking Interface (CNI) plugin-based implementation is demonstrated to perform QoS configuration for the 5G network. The proposed solution is validated with an existing localization and mapping application to verify the feasibility. The proposed solution has the following benefits: (1) The solution is a Kubernetes-native approach which adopts the CNI plugin mechanism. (2) The solution can expose the QoS information from an overlay network to an underlay network in a non-intrusive manner. (3) No packet manipulation is required to greatly reduce the overhead for packet processing. (4) It extends the K8s bandwidth limit feature from on-node to the access network. (5) It is compatible with the 5G infrastructure without any alteration or adding extra complexity.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Enabling 5G QoS Configuration Capabilities for IoT Applications on Container Orchestration Platform 1696843108707 10.1109/CloudCom59040.2023.00023 Yu Liu Ericsson Research, Sweden yu.a.liu@ericsson.com Aitor Hernandez Herranz Ericsson Research, Sweden aitor.hernandez.herranz@ericsson.com 5G QoS container orchestration platform container network interface device-cloud continuum Container orchestration platform is the foundation of modern cloud infrastructure. In recent years, container orchestration platform has been evolving to cross the boundary of device, edge, and cloud. More and more Internet of Things (IoT) applications such as robotics and eXtended Reality (XR) have been deployed across the device-cloud continuum through the container orchestration platform, e.g., the Kubernetes (K8s) framework. Meanwhile, the rapid expansion of advanced communication technologies like 5G has endorsed the revolution in IoT applications as more network resource is available for critical IoT use cases. This paper aims to integrate network configuration capabilities provided by a 5G Network Exposure Function (NEF) into the K8s framework which is used to simplify application deployment in an orchestration in the device-cloud continuum. Specifically, a Linux fwmark-based network Quality of Service (QoS) configuration method is proposed to expose the QoS information from an overlay network that is used by the container orchestration platform to the underlay network. A Container Networking Interface (CNI) plugin-based implementation is demonstrated to perform QoS configuration for the 5G network. The proposed solution is validated with an existing localization and mapping application to verify the feasibility. The proposed solution has the following benefits: (1) The solution is a Kubernetes-native approach which adopts the CNI plugin mechanism. (2) The solution can expose the QoS information from an overlay network to an underlay network in a non-intrusive manner. (3) No packet manipulation is required to greatly reduce the overhead for packet processing. (4) It extends the K8s bandwidth limit feature from on-node to the access network. (5) It is compatible with the 5G infrastructure without any alteration or adding extra complexity.",
							"pageNumber": 63,
							"isPageNumberRoman": false
						},
						{
							"eid": "2AvjjTLK7LAOsWidgIT7NY",
							"type": "authorPaper",
							"text": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf",
							"extraLocations": [],
							"authorNames": "Raj Narendra Shah (California State University, USA), Sameer Ahmed Mohamed (California State University, USA), Asif Imran (California State University, USA), Tevfik Kosar (University at Buffalo, USA)",
							"abstract": "The low cost and rapid provisioning capabilities have made open-source cloud a desirable platform to launch industrial applications. However, as open-source cloud moves towards maturity, it still suffers from quality issues like code smells. Although, a great emphasis has been provided on the economic benefits of deploying open-source cloud, low importance has been provided to improve the quality of the source code of the cloud itself to ensure its maintainability in the industrial scenario. Code refactoring has been associated with improving the maintenance and understanding of software code by removing code smells. However, analyzing what smells are more prevalent in cloud environment and designing a tool to define and detect those smells require further attention. In this paper, we propose a model called CloudScent which is an open source mechanism to detect smells in open-source cloud. We test our experiments in a real-life cloud environment using OpenStack. Results show that CloudScent is capable of accurately detecting 8 code smells in cloud. This will permit cloud service providers with advanced knowledge about the smells prevalent in open-source cloud platform, thus allowing for timely code refactoring and improving code quality of the cloud platforms. ",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 CloudScent: A Model for Code Smell Analysis in Open-Source Cloud 1697076328607 10.1109/CloudCom59040.2023.00024 Raj Narendra Shah California State University, USA shah068@csusm.edu Sameer Ahmed Mohamed California State University, USA moham135@csusm.edu Asif Imran California State University, USA aimran@csusm.edu Tevfik Kosar University at Buffalo, USA tkosar@buffalo.edu cloud software engineering cloud computing code smell refactoring open-source cloud code analysis The low cost and rapid provisioning capabilities have made open-source cloud a desirable platform to launch industrial applications. However, as open-source cloud moves towards maturity, it still suffers from quality issues like code smells. Although, a great emphasis has been provided on the economic benefits of deploying open-source cloud, low importance has been provided to improve the quality of the source code of the cloud itself to ensure its maintainability in the industrial scenario. Code refactoring has been associated with improving the maintenance and understanding of software code by removing code smells. However, analyzing what smells are more prevalent in cloud environment and designing a tool to define and detect those smells require further attention. In this paper, we propose a model called CloudScent which is an open source mechanism to detect smells in open-source cloud. We test our experiments in a real-life cloud environment using OpenStack. Results show that CloudScent is capable of accurately detecting 8 code smells in cloud. This will permit cloud service providers with advanced knowledge about the smells prevalent in open-source cloud platform, thus allowing for timely code refactoring and improving code quality of the cloud platforms.",
							"pageNumber": 69,
							"isPageNumberRoman": false
						},
						{
							"eid": "4iWHccjYnIeO2paOfJdi69",
							"type": "authorPaper",
							"text": "Recommendation Engine for Optimal Spark Delta Tables Partitioning",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a076/398200a076.pdf",
							"extraLocations": [],
							"authorNames": "Rui Esteves (University of Stavanger, Norway), H\u00E5vard Moe Jacobsen (University of Stavanger, Norway), Ola Andr\u00E8 Flotve (University of Stavanger, Norway)",
							"abstract": "The efficiency of a Spark-based ETL system relies significantly on the optimal partitioning of numerous Delta Tables, taking into account the query patterns of end-users and dataset characteristics. These factors are dynamic and challenging to predict in advance, emphasizing the need for an automated recommendation system for the current optimal partitioning of Delta Tables. Our work addresses this by developing a recommendation system that analyzes Spark logs and suggests the optimal partitioning and implementation of Z-ordering. Our system employs various original recommendation models, with each model contributing votes on dataset columns for partitioning and the applicability of Z-ordering. The recommendation system selects the optimization that carries more votes. To evaluate the efficiency of our system, we conducted benchmarks against another Spark recommendation engine for column partitioning developed by Gou et al. The results demonstrate that our system achieves almost identical performance compared to theirs. Our system provided a speed up between [17%, 19%] compared without the use of Z-order or explicitly partitioning, while their system provided an improvement between [19%, 20%]. However, our system has the great advantage of leveraging the readily available Spark logs integrated into the Spark platform, while Gou's approach necessitates collecting and analyzing inputs that are relatively complex.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Recommendation Engine for Optimal Spark Delta Tables Partitioning 1697601329481 10.1109/CloudCom59040.2023.00025 Rui Esteves University of Stavanger, Norway rui.esteves@uis.no H\u00E5vard Moe Jacobsen University of Stavanger, Norway ham.jacobsen@stud.uis.no Ola Andr\u00E8 Flotve University of Stavanger, Norway oa.flotve@stud.uis.no Delta table optimization Spark optimization Column partition Z-order The efficiency of a Spark-based ETL system relies significantly on the optimal partitioning of numerous Delta Tables, taking into account the query patterns of end-users and dataset characteristics. These factors are dynamic and challenging to predict in advance, emphasizing the need for an automated recommendation system for the current optimal partitioning of Delta Tables. Our work addresses this by developing a recommendation system that analyzes Spark logs and suggests the optimal partitioning and implementation of Z-ordering. Our system employs various original recommendation models, with each model contributing votes on dataset columns for partitioning and the applicability of Z-ordering. The recommendation system selects the optimization that carries more votes. To evaluate the efficiency of our system, we conducted benchmarks against another Spark recommendation engine for column partitioning developed by Gou et al. The results demonstrate that our system achieves almost identical performance compared to theirs. Our system provided a speed up between [17%, 19%] compared without the use of Z-order or explicitly partitioning, while their system provided an improvement between [19%, 20%]. However, our system has the great advantage of leveraging the readily available Spark logs integrated into the Spark platform, while Gou's approach necessitates collecting and analyzing inputs that are relatively complex.",
							"pageNumber": 76,
							"isPageNumberRoman": false
						},
						{
							"eid": "7gKjRBNY4aJ6K1ANI5wqOb",
							"type": "authorPaper",
							"text": "A Lightweight Routing Layer using a Reliable Link-Layer Protocol",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a082/398200a082.pdf",
							"extraLocations": [],
							"authorNames": "Qianfeng Shen (University of Toronto, Canada), Paul Chow (University of Toronto, Canada)",
							"abstract": "In today's data centers, the performance of interconnects plays a pivotal role. However, many of the underlying technologies for these interconnects have a history of several decades and existed long before data centers came into being. To better cater to the requirements of data center networks, particularly in the context of intra-rack communication, we have developed a new interconnect. This interconnect is based on a lossless link layer protocol, named RIFL. In this work, we designed and implemented RIFL Layer 2, a scalable network that supports up to multi-hundred Gbps communication. RIFL Layer 2 includes the RIFL switch and RIFL NIC. By utilizing a simple Batcher Banyan and iSLIP RIFL switch, we effectively keep the typical intra-rack latency under 400 nanoseconds. Moreover, for a 32-port 100Gbps network, under both Bernoulli arrival and bursty arrival traffic patterns, we ensure that the 99% tail latency does not exceed 12 microseconds.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 A Lightweight Routing Layer using a Reliable Link-Layer Protocol 1697669327931 10.1109/CloudCom59040.2023.00026 Qianfeng Shen University of Toronto, Canada qianfeng.shen@mail.utoronto.ca Paul Chow University of Toronto, Canada pc@eecg.toronto.edu Network switch Low latency Lossless switching In today's data centers, the performance of interconnects plays a pivotal role. However, many of the underlying technologies for these interconnects have a history of several decades and existed long before data centers came into being. To better cater to the requirements of data center networks, particularly in the context of intra-rack communication, we have developed a new interconnect. This interconnect is based on a lossless link layer protocol, named RIFL. In this work, we designed and implemented RIFL Layer 2, a scalable network that supports up to multi-hundred Gbps communication. RIFL Layer 2 includes the RIFL switch and RIFL NIC. By utilizing a simple Batcher Banyan and iSLIP RIFL switch, we effectively keep the typical intra-rack latency under 400 nanoseconds. Moreover, for a 32-port 100Gbps network, under both Bernoulli arrival and bursty arrival traffic patterns, we ensure that the 99% tail latency does not exceed 12 microseconds.",
							"pageNumber": 82,
							"isPageNumberRoman": false
						},
						{
							"eid": "6vY1RKoPBjp6XRud7eGHR8",
							"type": "authorPaper",
							"text": "A Flexible Trust Manager for Remote Attestation in Heterogeneous Critical Infrastructures",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a091/398200a091.pdf",
							"extraLocations": [],
							"authorNames": "Enrico Bravi (Politecnico di Torino, Italy), Diana Gratiela Berbecaru (Politecnico di Torino, Italy), Antonio Lioy (Politecnico di Torino, Italy)",
							"abstract": "Nowadays, critical infrastructures are managed through paradigms such as cloud/fog/edge computing and Network Function Virtualization (NFV), providing advantages as flexibility, availability, and reduced management costs. These paradigms introduce several advantages but \u2013 given their nature of physically distributed systems \u2013 leave room for various security threats, such as software integrity attacks. To counter these threats, Trusted Computing and Remote Attestation (RA) techniques can be used, to allow a third party (Verifier) to verify the software and configuration integrity of a platform (Attester). In environments composed of different objects, several RA frameworks (hardware-based, software-based, or hybrid) might need to be deployed, depending on the capabilities of the attested elements. To ease this process, we propose a new design and implementation of our Trust Monitor (TM) architecture, which implements the Trust Manager specified by ETSI for NFV environments, making it more flexible and usable in different contexts. In addition, we define a generic model for performing RA in heterogeneous environments by employing various RA technologies. More specifically, the extended TM allows flexible RA in hybrid infrastructures composed of different objects, i.e., physical nodes, virtual machines, containers, pods, and enclaves. Through tests performed in an experimental testbed, we show that the proposed implementation is scalable and usable in heterogeneous contexts.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 A Flexible Trust Manager for Remote Attestation in Heterogeneous Critical Infrastructures 1697556429582 10.1109/CloudCom59040.2023.00027 Enrico Bravi Politecnico di Torino, Italy enrico.bravi@polito.it Diana Gratiela Berbecaru Politecnico di Torino, Italy diana.berbecaru@polito.it Antonio Lioy Politecnico di Torino, Italy antonio.lioy@polito.it trusted computing cloud computing Trust Monitor Nowadays, critical infrastructures are managed through paradigms such as cloud/fog/edge computing and Network Function Virtualization (NFV), providing advantages as flexibility, availability, and reduced management costs. These paradigms introduce several advantages but \u2013 given their nature of physically distributed systems \u2013 leave room for various security threats, such as software integrity attacks. To counter these threats, Trusted Computing and Remote Attestation (RA) techniques can be used, to allow a third party (Verifier) to verify the software and configuration integrity of a platform (Attester). In environments composed of different objects, several RA frameworks (hardware-based, software-based, or hybrid) might need to be deployed, depending on the capabilities of the attested elements. To ease this process, we propose a new design and implementation of our Trust Monitor (TM) architecture, which implements the Trust Manager specified by ETSI for NFV environments, making it more flexible and usable in different contexts. In addition, we define a generic model for performing RA in heterogeneous environments by employing various RA technologies. More specifically, the extended TM allows flexible RA in hybrid infrastructures composed of different objects, i.e., physical nodes, virtual machines, containers, pods, and enclaves. Through tests performed in an experimental testbed, we show that the proposed implementation is scalable and usable in heterogeneous contexts.",
							"pageNumber": 91,
							"isPageNumberRoman": false
						},
						{
							"eid": "6hOJ2S3VvP3vYST27L1Piw",
							"type": "authorPaper",
							"text": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf",
							"extraLocations": [],
							"authorNames": "Felipe A. Portella (Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil; Barcelona Supercomputing Center (BSC), Spain; Universitat Polit\u00E8cnica de Catalunya (UPC), Spain), Paulo J. B. Estrela (Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil), Renzo Q. Malini (Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil), Luan Teylo (Institut National de Recherche en Informatique et en Automatique (Inria), France; Universidade Federal Fluminense (UFF), Brazil), Josep L. Berral (Universitat Polit\u00E8cnica de Catalunya (UPC), Spain; Barcelona Supercomputing Center (BSC), Spain), L\u00FAcia M. A. Drummond (Universidade Federal Fluminense (UFF), Brazil)",
							"abstract": "Petroleum reservoir simulation uses computer models to predict fluid flow in porous media, aiding to forecast oil production. Engineers execute numerous simulations with different geological realizations to refine the accuracy of the model. These experiments require considerable computational resources, which are not always available within the on-premises infrastructure. Commercial public cloud platforms can offer many advantages, such as virtually unlimited scalability and pay-per-use pricing. This paper introduces MSCHEDULER, a meta scheduler framework for reservoir simulations at Petrobras, a Brazilian energy company. It efficiently executes jobs in the cloud, utilizing spot Virtual Machines (VMs) to reduce costs and ensure job completion even with VM termination. Contributions include a novel methodology for reservoir simulation checkpointing, a cost-based scheduler, and an analysis of the strategy using real production jobs from Petrobras.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud 1697345937684 10.1109/CloudCom59040.2023.00028 Felipe A. Portella Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil; Barcelona Supercomputing Center (BSC), Spain; Universitat Polit\u00E8cnica de Catalunya (UPC), Spain felipeportella@petrobras.com.br Paulo J. B. Estrela Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil paulo.estrela@petrobras.com.br Renzo Q. Malini Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil renzo@petrobras.com.br Luan Teylo Institut National de Recherche en Informatique et en Automatique (Inria), France; Universidade Federal Fluminense (UFF), Brazil luan.teylo@inria.fr Josep L. Berral Universitat Polit\u00E8cnica de Catalunya (UPC), Spain; Barcelona Supercomputing Center (BSC), Spain josep.ll.berral@upc.edu L\u00FAcia M. A. Drummond Universidade Federal Fluminense (UFF), Brazil lucia@ic.uff.br Cloud Computing Spot Instances Reservoir Simulation Petroleum reservoir simulation uses computer models to predict fluid flow in porous media, aiding to forecast oil production. Engineers execute numerous simulations with different geological realizations to refine the accuracy of the model. These experiments require considerable computational resources, which are not always available within the on-premises infrastructure. Commercial public cloud platforms can offer many advantages, such as virtually unlimited scalability and pay-per-use pricing. This paper introduces MSCHEDULER, a meta scheduler framework for reservoir simulations at Petrobras, a Brazilian energy company. It efficiently executes jobs in the cloud, utilizing spot Virtual Machines (VMs) to reduce costs and ensure job completion even with VM termination. Contributions include a novel methodology for reservoir simulation checkpointing, a cost-based scheduler, and an analysis of the strategy using real production jobs from Petrobras.",
							"pageNumber": 99,
							"isPageNumberRoman": false
						},
						{
							"eid": "7k19wb8mTtP9ef1eTkNpVf",
							"type": "authorPaper",
							"text": "Depot: Dependency-Eager Platform of Transformations",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf",
							"extraLocations": [],
							"authorNames": "Kerem Celik (UCSB Computer Science Department, USA), Samridhi Maheshwari (UCSB Computer Science Department, USA), Shereen ElSayed (UCSB Computer Science Department, USA), Markus Mock (HAW Landshut, Germany), Chandra Krintz (UCSB Computer Science Department, USA), Rich Wolski (UCSB Computer Science Department, USA)",
							"abstract": "This paper presents a new model for a data management system specifically designed to enable community-curated data repositories and collaboration. Depot (a Dependence-Eager Platform of Transformations) is based on a data-lake approach that eases the technological burdens associated with data contribution while providing an interactive programming environment for developing transformations that result in structured tables supporting SQL database operations. Crucially, Depot implements lazy evaluation of these transformations so that only the structured data that is demanded by a data consumer is generated. Until the structured data is \"materialized,\" Depot tracks and maintains the dependencies that are required to per-form the eventual materialization. This lazy approach to creating structured data allows Depot to maintain a smaller resource footprint compared to a typical data warehouse approach while maintaining the flexibility of the data lake model. Furthermore, Depot is designed as a community-sustainable platform. The initial prototype is implemented for cloud deployment and it distributes the storage and ETL workload cost among the data consumers. Performance results of the early prototype are encouraging, making Depot a new infrastructure for creating data lakes that foster contributed-consumer collaboration.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Depot: Dependency-Eager Platform of Transformations 1697495134516 10.1109/CloudCom59040.2023.00029 Kerem Celik UCSB Computer Science Department, USA kerem@ucsb.edu Samridhi Maheshwari UCSB Computer Science Department, USA samridhimaheshwari@ucsb.edu Shereen ElSayed UCSB Computer Science Department, USA s_elsayed@ucsb.edu Markus Mock HAW Landshut, Germany mock@haw-landshut.de Chandra Krintz UCSB Computer Science Department, USA ckrintz@cs.ucsb.edu Rich Wolski UCSB Computer Science Department, USA rich@cs.ucsb.edu data lake cloud services for science This paper presents a new model for a data management system specifically designed to enable community-curated data repositories and collaboration. Depot (a Dependence-Eager Platform of Transformations) is based on a data-lake approach that eases the technological burdens associated with data contribution while providing an interactive programming environment for developing transformations that result in structured tables supporting SQL database operations. Crucially, Depot implements lazy evaluation of these transformations so that only the structured data that is demanded by a data consumer is generated. Until the structured data is \"materialized,\" Depot tracks and maintains the dependencies that are required to per-form the eventual materialization. This lazy approach to creating structured data allows Depot to maintain a smaller resource footprint compared to a typical data warehouse approach while maintaining the flexibility of the data lake model. Furthermore, Depot is designed as a community-sustainable platform. The initial prototype is implemented for cloud deployment and it distributes the storage and ETL workload cost among the data consumers. Performance results of the early prototype are encouraging, making Depot a new infrastructure for creating data lakes that foster contributed-consumer collaboration.",
							"pageNumber": 107,
							"isPageNumberRoman": false
						},
						{
							"eid": "kJOyb9N5Hy6kRBcIeoNXU",
							"type": "authorPaper",
							"text": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf",
							"extraLocations": [],
							"authorNames": "Marlon H. Schweigert (Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil), Diego E.G.C. de Oliveira (Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil), Guilherme P. Koslovski (Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil), Maur\u00EDcio A. Pillon (Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil), Charles C. Miers (Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil)",
							"abstract": "The popularization increase of MMORPGs demands new technological approaches to supply users' requirements with a lower cost of computational resources. Designing these architectures, from the network point of view, is relevant and impacts these games' success. We analyze and identify the computational resources consumed by the architectures Rudy, Salz, and Willson, which are microservices architectures elaborated for MMORPGs. These architectures were analyzed and tested using automated clients on the architectures deployed in our private computational cloud to identify resource bottlenecks. We conclude the performance, from the point of view of response time, is related to better use of CPU, either by data storage microservices or by data processing microservices. In addition, the application of queuing systems or barriers to manage access or minimize the consumption of an internal service proved feasible, directly impacting the flow of data through the architecture.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG) 1697686111832 10.1109/CloudCom59040.2023.00030 Marlon H. Schweigert Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil marlon@schweigert.com.br Diego E.G.C. de Oliveira Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil diego.egcdo@edu.udesc.br Guilherme P. Koslovski Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil guilherme.koslovski@udesc.br Maur\u00EDcio A. Pillon Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil mauricio.pillon@udesc.br Charles C. Miers Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil charles.miers@udesc.br Microservice MMORPG Cloud Performance The popularization increase of MMORPGs demands new technological approaches to supply users' requirements with a lower cost of computational resources. Designing these architectures, from the network point of view, is relevant and impacts these games' success. We analyze and identify the computational resources consumed by the architectures Rudy, Salz, and Willson, which are microservices architectures elaborated for MMORPGs. These architectures were analyzed and tested using automated clients on the architectures deployed in our private computational cloud to identify resource bottlenecks. We conclude the performance, from the point of view of response time, is related to better use of CPU, either by data storage microservices or by data processing microservices. In addition, the application of queuing systems or barriers to manage access or minimize the consumption of an internal service proved feasible, directly impacting the flow of data through the architecture.",
							"pageNumber": 115,
							"isPageNumberRoman": false
						},
						{
							"eid": "2uR4b6jzTRqkj3mVawqfwO",
							"type": "authorPaper",
							"text": "Can Software Containerisation Fit The Car On-Board Systems ?",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf",
							"extraLocations": [],
							"authorNames": "David Fern\u00E1ndez Blanco (Univ Lyon, INSA LYON, Inria, CITI, France; STELLANTIS, France), Fr\u00E9d\u00E9ric Le Mou\u00EBl (Univ Lyon, INSA LYON, Inria, CITI, France), Trista Lin (STELLANTIS, France), Amir Rekik (STELLANTIS, France)",
							"abstract": "As the automotive industry evolves towards interconnected and intelligent vehicles, the integration of complex electronic and software components has become paramount. However, this increased complexity brings new challenges in ensuring system safety, security, and life-cycle management. In this article, we focus on virtualisation (virt.), particularly containerisation (cont.), as a solution to mitigate integration stress in multi-node environments. We present a detailed review of the automotive constraints and ecosystem, along with the selection criteria for virt. technologies, justifying the scope of our study. Our main contribution is a two-phased evaluation of cont. tools. Firstly, we assess popular single-node container engines (Docker, Containerd, and Linux Containers LXC) based on CPU, RAM, and file I/O overhead over multiple hardware configurations. Secondly, we evaluate their multi-node scalability. The results show that Docker performs in average better than the other solutions for automotive on-board architectures.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Can Software Containerisation Fit The Car On-Board Systems ? 1696582128012 10.1109/CloudCom59040.2023.00031 David Fern\u00E1ndez Blanco Univ Lyon, INSA LYON, Inria, CITI, France; STELLANTIS, France david.fernandez-blanco@insa-lyon.fr Fr\u00E9d\u00E9ric Le Mou\u00EBl Univ Lyon, INSA LYON, Inria, CITI, France n/a Trista Lin STELLANTIS, France n/a Amir Rekik STELLANTIS, France n/a Containerisation Automotive ICT systems Micro-processor Units (MPUs) Multi-node Dynamicity As the automotive industry evolves towards interconnected and intelligent vehicles, the integration of complex electronic and software components has become paramount. However, this increased complexity brings new challenges in ensuring system safety, security, and life-cycle management. In this article, we focus on virtualisation (virt.), particularly containerisation (cont.), as a solution to mitigate integration stress in multi-node environments. We present a detailed review of the automotive constraints and ecosystem, along with the selection criteria for virt. technologies, justifying the scope of our study. Our main contribution is a two-phased evaluation of cont. tools. Firstly, we assess popular single-node container engines (Docker, Containerd, and Linux Containers LXC) based on CPU, RAM, and file I/O overhead over multiple hardware configurations. Secondly, we evaluate their multi-node scalability. The results show that Docker performs in average better than the other solutions for automotive on-board architectures.",
							"pageNumber": 123,
							"isPageNumberRoman": false
						},
						{
							"eid": "3TMOl6Gq28v7FQtoNqz1mq",
							"type": "authorPaper",
							"text": "Cost-Optimized Scheduling for Microservices in Kubernetes",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a131/398200a131.pdf",
							"extraLocations": [],
							"authorNames": "Sugunakumar Arunan (University of Moratuwa, Sri Lanka), Gayashan Amarasinghe (University of Moratuwa, Sri Lanka), Indika Perera (University of Moratuwa, Sri Lanka)",
							"abstract": "The usage of Kubernetes for running microservices applications is increasing nowadays. In a particular application, all microservices do not have the same priority. Hence it is costly to allocate the same resources to both high and low-priority services. This research aims to utilize spot instances to run low-priority services with the intention of reducing the cloud cost and providing overall high availability to the application. A service called KubeEconomy has been proposed to monitor and manage Kubernetes worker nodes. Three functionalities of the KubeEconomy service have been explained and it is shown that it is possible to reduce the cloud cost while maintaining high availability for the microservices.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Cost-Optimized Scheduling for Microservices in Kubernetes 1697689506854 10.1109/CloudCom59040.2023.00032 Sugunakumar Arunan University of Moratuwa, Sri Lanka sugunakumar.21@cse.mrt.ac.lk Gayashan Amarasinghe University of Moratuwa, Sri Lanka gayashan@cse.mrt.ac.lk Indika Perera University of Moratuwa, Sri Lanka indika@cse.mrt.ac.lk Cloud computing Container Orchestration Kubernetes Microservices Cost Optimization High availability Spot Instances The usage of Kubernetes for running microservices applications is increasing nowadays. In a particular application, all microservices do not have the same priority. Hence it is costly to allocate the same resources to both high and low-priority services. This research aims to utilize spot instances to run low-priority services with the intention of reducing the cloud cost and providing overall high availability to the application. A service called KubeEconomy has been proposed to monitor and manage Kubernetes worker nodes. Three functionalities of the KubeEconomy service have been explained and it is shown that it is possible to reduce the cloud cost while maintaining high availability for the microservices.",
							"pageNumber": 131,
							"isPageNumberRoman": false
						},
						{
							"eid": "vZogfZIoPPdnx0TwiisYf",
							"type": "authorPaper",
							"text": "Lightweight Cloud Application Sandboxing",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf",
							"extraLocations": [],
							"authorNames": "Marco Abbadini (Universit\u00E0 degli Studi di Bergamo, Italy), Michele Beretta (Universit\u00E0 degli Studi di Bergamo, Italy), Dario Facchinetti (Universit\u00E0 degli Studi di Bergamo, Italy), Gianluca Oldani (Universit\u00E0 degli Studi di Bergamo, Italy), Matthew Rossi (Universit\u00E0 degli Studi di Bergamo, Italy), Stefano Paraboschi (Universit\u00E0 degli Studi di Bergamo, Italy)",
							"abstract": "Modern cloud applications can quickly grow to an elaborate and intricate tangle of services. In this scenario, paying attention to security aspects is important to mitigate the impact of incidents. Indeed, several research works and industrial standards recommend the integration of least privilege policies to prevent disruptions such as file system tampering. Unfortunately, technologies like containers virtualize file system resources with a volume-based approach, which may be overly coarse. In this work we address this problem proposing an approach that restrict application access to file system resources with a resource-based granularity. To this end, we develop a flexible and intuitive tool that relies on instrumentation to collect, merge, and audit the activity traces generated by any application component. We then demonstrate how this information is used to create fine-grained access policies, and introduce sandboxing using recent kernel security modules, strengthening the security boundary of the whole application. In the experimental evaluation we showcase the mitigation capabilities associated with our approach, and the low performance footprint. The proposal is associated with an open source implementation.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Lightweight Cloud Application Sandboxing 1697029322080 10.1109/CloudCom59040.2023.00033 Marco Abbadini Universit\u00E0 degli Studi di Bergamo, Italy marco.abbadini@unibg.it Michele Beretta Universit\u00E0 degli Studi di Bergamo, Italy michele.beretta@unibg.it Dario Facchinetti Universit\u00E0 degli Studi di Bergamo, Italy dario.facchinetti@unibg.it Gianluca Oldani Universit\u00E0 degli Studi di Bergamo, Italy gianluca.oldani@unibg.it Matthew Rossi Universit\u00E0 degli Studi di Bergamo, Italy matthew.rossi@unibg.it Stefano Paraboschi Universit\u00E0 degli Studi di Bergamo, Italy stefano.paraboschi@unibg.it Cloud monitoring instrumentation sandbox Modern cloud applications can quickly grow to an elaborate and intricate tangle of services. In this scenario, paying attention to security aspects is important to mitigate the impact of incidents. Indeed, several research works and industrial standards recommend the integration of least privilege policies to prevent disruptions such as file system tampering. Unfortunately, technologies like containers virtualize file system resources with a volume-based approach, which may be overly coarse. In this work we address this problem proposing an approach that restrict application access to file system resources with a resource-based granularity. To this end, we develop a flexible and intuitive tool that relies on instrumentation to collect, merge, and audit the activity traces generated by any application component. We then demonstrate how this information is used to create fine-grained access policies, and introduce sandboxing using recent kernel security modules, strengthening the security boundary of the whole application. In the experimental evaluation we showcase the mitigation capabilities associated with our approach, and the low performance footprint. The proposal is associated with an open source implementation.",
							"pageNumber": 139,
							"isPageNumberRoman": false
						},
						{
							"eid": "uSjh7PJROHnQZY7HayDgu",
							"type": "authorPaper",
							"text": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf",
							"extraLocations": [],
							"authorNames": "Jiahe Xu (City University of Hong Kong, P.R. China), Jing Fu (RMIT University, Australia), Jingjin Wu (BNU-HKBU United International College, P.R. China), Moshe Zukerman (City University of Hong Kong, P.R. China)",
							"abstract": "We focus on energy-efficient offloading strategies in a slicing-enabled large-scale edge network, or an \"edge slicing\" system, with different computing/storage components, on which the service capacities are dynamically released and reused by the incoming user requests. The offloading problem is challenged by its large problem size and the heterogeneity of the service components and user requests, leading to the high-dimensional state space of the underlying stochastic process. We formulate the problem in the manner of the restless-bandit-based (RB-based) resource allocation problem and generalize unrealistic previously made assumptions on specific forms of the power functions, such as linearity, convexity, and taking only binary power states. We adapt the RB-based resource allocation technique to the offloading problem. We quantify actions of selecting certain service components to serve requests through marginal rewards, which take consideration of both the history and future effects of the corresponding action. The marginal rewards exist in closed forms when assuming linear power functions, but it remains an open question in the non-linear case. We approximate the marginal rewards by introducing state-dependent coefficients that compensate for the undesirable effects of non-linearity. We propose a scheduling policy that always prioritizes the service components with the highest marginal rewards, which is simple and applicable in the large-scale case. In the special case with linear power functions, the policy becomes asymptotically optimalit approaches optimality when the number of components tends to infinity. We numerically demonstrate the effectiveness and robustness of the proposed policy in practical situations with respect to energy efficiency.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions 1697252292324 10.1109/CloudCom59040.2023.00034 Jiahe Xu City University of Hong Kong, P.R. China jiahexu3-c@my.cityu.edu.hk Jing Fu RMIT University, Australia jing.fu@rmit.edu.au Jingjin Wu BNU-HKBU United International College, P.R. China jj.wu@ieee.org Moshe Zukerman City University of Hong Kong, P.R. China m.zu@cityu.edu.hk Energy efficiency edge slicing stochastic modeling We focus on energy-efficient offloading strategies in a slicing-enabled large-scale edge network, or an \"edge slicing\" system, with different computing/storage components, on which the service capacities are dynamically released and reused by the incoming user requests. The offloading problem is challenged by its large problem size and the heterogeneity of the service components and user requests, leading to the high-dimensional state space of the underlying stochastic process. We formulate the problem in the manner of the restless-bandit-based (RB-based) resource allocation problem and generalize unrealistic previously made assumptions on specific forms of the power functions, such as linearity, convexity, and taking only binary power states. We adapt the RB-based resource allocation technique to the offloading problem. We quantify actions of selecting certain service components to serve requests through marginal rewards, which take consideration of both the history and future effects of the corresponding action. The marginal rewards exist in closed forms when assuming linear power functions, but it remains an open question in the non-linear case. We approximate the marginal rewards by introducing state-dependent coefficients that compensate for the undesirable effects of non-linearity. We propose a scheduling policy that always prioritizes the service components with the highest marginal rewards, which is simple and applicable in the large-scale case. In the special case with linear power functions, the policy becomes asymptotically optimalit approaches optimality when the number of components tends to infinity. We numerically demonstrate the effectiveness and robustness of the proposed policy in practical situations with respect to energy efficiency.",
							"pageNumber": 147,
							"isPageNumberRoman": false
						},
						{
							"eid": "PvKr8dXVRNmRbAx42kliu",
							"type": "authorPaper",
							"text": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf",
							"extraLocations": [],
							"authorNames": "Jo\u00E3o H. F. Battisti (Santa Catarina State University (UDESC), Brazil), Vitor E. Batista (Santa Catarina State University (UDESC), Brazil), Guilherme P. Koslovski (Santa Catarina State University (UDESC), Brazil), Maur\u00EDcio A. Pillon (Santa Catarina State University (UDESC), Brazil), Charles C. Miers (Santa Catarina State University (UDESC), Brazil), Marco A. Marques (Universidade de S\u00E3o Paulo (USP), Brazil), Marcos Simpl\u00EDcio (Universidade de S\u00E3o Paulo (USP), Brazil), Diego Kreutz (Federal University of Pampa (Unipampa), Brazil)",
							"abstract": "The use of private or consortium blockchains in organizations' applications is growing. A relevant aspect of blockchains is the choice of consensus mechanism. This decision delimits which blockchain solutions are suitable for the private scenario. Once the consensus mechanism is chosen, more than one blockchain may be enabled. However, this decision making is not trivial and requires detailed experimental indicators about algorithms and blockchains performance. In this context, we provide a comprehensive performance analysis of the Raft consensus mechanism based on its implementation in Hyperledger Fabric and Ethereum blockchain solutions. We performed our experiments on an OpenStack private cloud using each blockchain developer's default settings for virtual machines. Our findings show how the implementation of each solution can impact the application's performance under certain conditions.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud 1697687292496 10.1109/CloudCom59040.2023.00035 Jo\u00E3o H. F. Battisti Santa Catarina State University (UDESC), Brazil joaobattisti@gmail.com Vitor E. Batista Santa Catarina State University (UDESC), Brazil vitor.batista@edu.udesc.br Guilherme P. Koslovski Santa Catarina State University (UDESC), Brazil guilherme.koslovski@udesc.br Maur\u00EDcio A. Pillon Santa Catarina State University (UDESC), Brazil mauricio.pillon@udesc.br Charles C. Miers Santa Catarina State University (UDESC), Brazil charles.miers@udesc.br Marco A. Marques Universidade de S\u00E3o Paulo (USP), Brazil mmarques@larc.usp.br Marcos Simpl\u00EDcio Universidade de S\u00E3o Paulo (USP), Brazil mjunior@larc.usp.br Diego Kreutz Federal University of Pampa (Unipampa), Brazil diegokreutz@unipampa.edu.br Blockchain Raft Ethereum Hyperledger Fabric OpenStack The use of private or consortium blockchains in organizations' applications is growing. A relevant aspect of blockchains is the choice of consensus mechanism. This decision delimits which blockchain solutions are suitable for the private scenario. Once the consensus mechanism is chosen, more than one blockchain may be enabled. However, this decision making is not trivial and requires detailed experimental indicators about algorithms and blockchains performance. In this context, we provide a comprehensive performance analysis of the Raft consensus mechanism based on its implementation in Hyperledger Fabric and Ethereum blockchain solutions. We performed our experiments on an OpenStack private cloud using each blockchain developer's default settings for virtual machines. Our findings show how the implementation of each solution can impact the application's performance under certain conditions.",
							"pageNumber": 155,
							"isPageNumberRoman": false
						},
						{
							"eid": "3N5mbMDyFuWeAdFJLVfqk9",
							"type": "authorPaper",
							"text": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf",
							"extraLocations": [],
							"authorNames": "Demetris Trihinas (University of Nicosia), Moysis Symeonides (University of Cyprus), Joanna Georgiou (University of Cyprus), George Pallis (University of Cyprus), Marios D. Dikaiakos (University of Cyprus)",
							"abstract": "Energy profiling and optimization are expected to be crucial factors impacting the realisation of the Internet of Things (IoT) as more intelligence is deployed at the network extremes to achieve better response times in the proximity of where data are harvested. To improve the performance of streaming analytics jobs, several schedulers have been designed to tackle key challenges in edge computing realms, including resource heterogeneity and highly volatile network links. However, energy-aware scheduling for streaming analytic jobs is at best, not adequately examined. In this article, we introduce PowerStorm, a scheduler for streaming analytic jobs that is designed to explore trade-offs between performance and energy consumption in geo-distributed edge computing settings. We implement our scheduler for Apache Storm and show the scheduler's energy saving capabilities over the Yahoo streaming benchmark with worker nodes featuring heterogeneous power and resource capabilities on both a physical and emulated testbed.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Energy-Aware Streaming Analytics Job Scheduling for Edge Computing 1696924463360 10.1109/CloudCom59040.2023.00036 Demetris Trihinas University of Nicosia trihinas.d@unic.ac.cy Moysis Symeonides University of Cyprus msymeo03@ucy.ac.cy Joanna Georgiou University of Cyprus jgeorg02@ucy.ac.cy George Pallis University of Cyprus pallis@ucy.ac.cy Marios D. Dikaiakos University of Cyprus mdd@ucy.ac.cy Big Data Internet of Things Energy Profiling Energy profiling and optimization are expected to be crucial factors impacting the realisation of the Internet of Things (IoT) as more intelligence is deployed at the network extremes to achieve better response times in the proximity of where data are harvested. To improve the performance of streaming analytics jobs, several schedulers have been designed to tackle key challenges in edge computing realms, including resource heterogeneity and highly volatile network links. However, energy-aware scheduling for streaming analytic jobs is at best, not adequately examined. In this article, we introduce PowerStorm, a scheduler for streaming analytic jobs that is designed to explore trade-offs between performance and energy consumption in geo-distributed edge computing settings. We implement our scheduler for Apache Storm and show the scheduler's energy saving capabilities over the Yahoo streaming benchmark with worker nodes featuring heterogeneous power and resource capabilities on both a physical and emulated testbed.",
							"pageNumber": 161,
							"isPageNumberRoman": false
						},
						{
							"eid": "01q2iey11ogMiVwUR42Xac",
							"type": "authorPaper",
							"text": "Triad: Trusted Timestamps in Untrusted Environments",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a169/398200a169.pdf",
							"extraLocations": [],
							"authorNames": "Gabriel Fernandez (TU-Dresden, Germany), Andrey Brito (UFCG, Brazil), Christof Fetzer (TU-Dresden, Germany)",
							"abstract": "We aim to provide trusted time measurement mechanisms to applications and cloud infrastructure deployed in environments that could harbor potential adversaries, including the hardware infrastructure provider. Despite Trusted Execution Environments (TEEs) providing multiple security functionalities, timestamps from the Operating System are not covered. Nevertheless, some services require time for validating permissions or ordering events. To address that need, we introduce Triad, a trusted timestamp dispatcher of time readings. The solution provides trusted timestamps enforced by mutually supportive enclave-based clock servers that create a continuous trusted timeline. We leverage enclave properties such as forced exits and CPU-based counters to mitigate attacks on the server's timestamp counters. Triad produces trusted, confidential, monotonically-increasing timestamps with bounded error and desirable, non-trivial properties. Our implementation relies on Intel SGX and SCONE, allowing transparent usage. We evaluate Triad's error and behavior in multiple dimensions.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Triad: Trusted Timestamps in Untrusted Environments 1697727421989 10.1109/CloudCom59040.2023.00037 Gabriel Fernandez TU-Dresden, Germany gabriel.pereira_fernandez@tu-dresden.de Andrey Brito UFCG, Brazil andrey@computacao.ufcg.edu.br Christof Fetzer TU-Dresden, Germany christof.fetzer@tu-dresden.de Trusted Computing Distributed Systems TEE Trusted Clocks We aim to provide trusted time measurement mechanisms to applications and cloud infrastructure deployed in environments that could harbor potential adversaries, including the hardware infrastructure provider. Despite Trusted Execution Environments (TEEs) providing multiple security functionalities, timestamps from the Operating System are not covered. Nevertheless, some services require time for validating permissions or ordering events. To address that need, we introduce Triad, a trusted timestamp dispatcher of time readings. The solution provides trusted timestamps enforced by mutually supportive enclave-based clock servers that create a continuous trusted timeline. We leverage enclave properties such as forced exits and CPU-based counters to mitigate attacks on the server's timestamp counters. Triad produces trusted, confidential, monotonically-increasing timestamps with bounded error and desirable, non-trivial properties. Our implementation relies on Intel SGX and SCONE, allowing transparent usage. We evaluate Triad's error and behavior in multiple dimensions.",
							"pageNumber": 169,
							"isPageNumberRoman": false
						},
						{
							"eid": "3FzPNbXbUWTcg2zQ1Levwp",
							"type": "authorPaper",
							"text": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf",
							"extraLocations": [],
							"authorNames": "Georgios Fatouros (University of Piraeus, Greece), Georgios Kousiouris (Harokopio University, Greece), Georgios Makridis (University of Piraeus, Greece), John Soldatos (Innov-Acts Ltd, Cyprus), Michael Filippakis (University of Piraeus, Greece), Dimosthenis Kyriazis (University of Piraeus, Greece)",
							"abstract": "Serverless computing has reshaped the cloud computing landscape by offering benefits such as auto-scalability, streamlined operational management, and granular billing. As its adoption grows, challenges related to performance and cost optimization in hybrid architectures combining private servers and public cloud clusters have emerged. Central to these challenges are achieving optimal response latency and balancing performance and cost. To address these challenges, this paper introduces an adaptive routing service specifically designed for hybrid environments, proficient in leveraging real-time function metrics. Our proposed service pivots on three integral components: a monitor that captures performance metrics and raises alarms for predefined anomalies; a forecaster that predicts function latency across clusters, which includes wait and execution times and produces request distributions for each cluster to equalize the overall function latency; and a router then processes incoming requests, taking cues from the forecaster's predictions. Notably, based on user-defined objectives, the forecaster can be directed to either minimize latency or optimize execution costs through trading off wait or execution time. Comprehensive evaluations on AWS and Azure clusters using the open source FaaS framework Apache OpenWhisk showcase our approach's effectiveness, yielding a 9% improvement in average latency, a 45% decrease in standard deviation latency and a 17% cost reduction compared to conventional 50-50 routing. The advantages of elevated monitoring frequency are also illuminated, emphasizing quicker convergence times.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings 1696537750875 10.1109/CloudCom59040.2023.00038 Georgios Fatouros University of Piraeus, Greece n/a Georgios Kousiouris Harokopio University, Greece n/a Georgios Makridis University of Piraeus, Greece n/a John Soldatos Innov-Acts Ltd, Cyprus n/a Michael Filippakis University of Piraeus, Greece n/a Dimosthenis Kyriazis University of Piraeus, Greece n/a serverless computing function-as-a-service runtime adaptation openwhisk performance forecasting routing Serverless computing has reshaped the cloud computing landscape by offering benefits such as auto-scalability, streamlined operational management, and granular billing. As its adoption grows, challenges related to performance and cost optimization in hybrid architectures combining private servers and public cloud clusters have emerged. Central to these challenges are achieving optimal response latency and balancing performance and cost. To address these challenges, this paper introduces an adaptive routing service specifically designed for hybrid environments, proficient in leveraging real-time function metrics. Our proposed service pivots on three integral components: a monitor that captures performance metrics and raises alarms for predefined anomalies; a forecaster that predicts function latency across clusters, which includes wait and execution times and produces request distributions for each cluster to equalize the overall function latency; and a router then processes incoming requests, taking cues from the forecaster's predictions. Notably, based on user-defined objectives, the forecaster can be directed to either minimize latency or optimize execution costs through trading off wait or execution time. Comprehensive evaluations on AWS and Azure clusters using the open source FaaS framework Apache OpenWhisk showcase our approach's effectiveness, yielding a 9% improvement in average latency, a 45% decrease in standard deviation latency and a 17% cost reduction compared to conventional 50-50 routing. The advantages of elevated monitoring frequency are also illuminated, emphasizing quicker convergence times.",
							"pageNumber": 177,
							"isPageNumberRoman": false
						},
						{
							"eid": "6XUu1WAd9oiwV82twLLdDX",
							"type": "authorPaper",
							"text": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf",
							"extraLocations": [],
							"authorNames": "Siqi Zhang (The Hong Kong Polytechnic University, China), Minjie Cai (The Hong Kong Polytechnic University, China), Mengyuan Zhang (The Hong Kong Polytechnic University, China), Lianying Zhao (Carleton University, Canada), Xavier de Carn\u00E9 de Carnavalet (The Hong Kong Polytechnic University, China)",
							"abstract": "Cloud security frameworks, like OpenSCAP, rely on vulnerability databases such as the National Vulnerability Database (NVD) to assess threats, ensure compliance, and manage patches efficiently. However, despite their popularity, vulnerability databases are not exempt from errors. Prior research showed inconsistencies between multiple databases, as well as incorrect software or vendor names, and publication dates. In this study, we discovered and proposed a systematic approach to detect a new form of inconsistency whereby entries with identical or semantically similar vulnerability descriptions are assigned distanced scores, which can skew risk assessments, and potentially misguide mitigation strategies. Our analysis identified 12,866 entries suffering from such inconsistencies, highlighting the most error-prone Common Vulnerability Scoring System (CVSS) metrics and vulnerability types, as well as the observed score deviation. We believe our study can bring this inconsistency issue to the community's attention and pave the way for further investigation thereof.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 The Flaw Within: Identifying CVSS Score Discrepancies in the NVD 1697695396487 10.1109/CloudCom59040.2023.00039 Siqi Zhang The Hong Kong Polytechnic University, China siqi0510.zhang@connect.polyu.hk Minjie Cai The Hong Kong Polytechnic University, China minjie.cai@polyu.edu.hk Mengyuan Zhang The Hong Kong Polytechnic University, China mengyuan.zhang@polyu.edu.hk Lianying Zhao Carleton University, Canada lianying.zhao@carleton.ca Xavier de Carn\u00E9 de Carnavalet The Hong Kong Polytechnic University, China xdecarne@polyu.edu.hk NVD Security assessment CVSS Machine Learning Vulnerability analysis Inconsistency in NVD Cloud security frameworks, like OpenSCAP, rely on vulnerability databases such as the National Vulnerability Database (NVD) to assess threats, ensure compliance, and manage patches efficiently. However, despite their popularity, vulnerability databases are not exempt from errors. Prior research showed inconsistencies between multiple databases, as well as incorrect software or vendor names, and publication dates. In this study, we discovered and proposed a systematic approach to detect a new form of inconsistency whereby entries with identical or semantically similar vulnerability descriptions are assigned distanced scores, which can skew risk assessments, and potentially misguide mitigation strategies. Our analysis identified 12,866 entries suffering from such inconsistencies, highlighting the most error-prone Common Vulnerability Scoring System (CVSS) metrics and vulnerability types, as well as the observed score deviation. We believe our study can bring this inconsistency issue to the community's attention and pave the way for further investigation thereof.",
							"pageNumber": 185,
							"isPageNumberRoman": false
						},
						{
							"eid": "5AhxeNVcYHWXyTgxhXpDBP",
							"type": "authorPaper",
							"text": "Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a193/398200a193.pdf",
							"extraLocations": [],
							"authorNames": "Di Mo (University of Washington, USA), Robert Cordingly (University of Washington, USA), Donald Chinn (University of Washington, USA), Wes Lloyd (University of Washington, USA)",
							"abstract": "Serverless Function-as-a-Service (FaaS) platforms enable easy deployment and hosting of microservices and have gained great traction among software developers. FaaS platforms, however, only host compute-based functionality of applications resulting in vendor lock-in as applications rely on supporting services known as Backend-as-a-Service (BaaS) offered by the cloud provider for key features such as data persistence. Migrating FaaS code to different cloud providers is made more challenging as a result of these dependencies on vendor-specific services. Cloud service abstraction libraries have been developed to alleviate vendor lock-in, but these libraries were largely developed prior to the advent of serverless computing and have not been evaluated in this context. This paper investigates the use of cloud service abstraction libraries to interface with object storage, a key BaaS used in FaaS code. We investigate the utility of these libraries to improve the portability of code to enable easier migration between cloud providers. We investigate performance of seven FaaS functions on AWS and Google Cloud that use object storage using the Apache jclouds abstraction library vs. platform-specific APIs and assess code quality metrics. We then conduct an empirical study leveraging computer science students enrolled in cloud computing courses to assess the impact of cloud abstraction libraries on FaaS function code portability.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction 1697767972441 10.1109/CloudCom59040.2023.00040 Di Mo University of Washington, USA dimo@uw.edu Robert Cordingly University of Washington, USA rcording@uw.edu Donald Chinn University of Washington, USA dchinn@uw.edu Wes Lloyd University of Washington, USA wlloyd@uw.edu Serverless Computing FaaS Vendor Lock-In Multi-Cloud Cloud Portability Cloud Interoperability Serverless Function-as-a-Service (FaaS) platforms enable easy deployment and hosting of microservices and have gained great traction among software developers. FaaS platforms, however, only host compute-based functionality of applications resulting in vendor lock-in as applications rely on supporting services known as Backend-as-a-Service (BaaS) offered by the cloud provider for key features such as data persistence. Migrating FaaS code to different cloud providers is made more challenging as a result of these dependencies on vendor-specific services. Cloud service abstraction libraries have been developed to alleviate vendor lock-in, but these libraries were largely developed prior to the advent of serverless computing and have not been evaluated in this context. This paper investigates the use of cloud service abstraction libraries to interface with object storage, a key BaaS used in FaaS code. We investigate the utility of these libraries to improve the portability of code to enable easier migration between cloud providers. We investigate performance of seven FaaS functions on AWS and Google Cloud that use object storage using the Apache jclouds abstraction library vs. platform-specific APIs and assess code quality metrics. We then conduct an empirical study leveraging computer science students enrolled in cloud computing courses to assess the impact of cloud abstraction libraries on FaaS function code portability.",
							"pageNumber": 193,
							"isPageNumberRoman": false
						},
						{
							"eid": "1j41ZISXVqizGPAHqHj41B",
							"type": "authorPaper",
							"text": "Peer-to-Peer Approach for Edge Computing Services",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a200/398200a200.pdf",
							"extraLocations": [],
							"authorNames": "Muhammad Anjum Malik (Fachhochschule Dortmund, Germany), Tobias Pleuger (Fachhochschule Dortmund, Germany), Stephan Recker (Fachhochschule Dortmund, Germany)",
							"abstract": "Services in the Cloud-Edge continuum and Multi-access Edge Computing have received continuously increasing attention in industry and research. The majority of cloud-edge solutions, specifically those that support ultralow latency services, are based on a centrally deployed edge services orchestrator that allocates resources in all involved cloud-edge components and in the interconnecting infrastructure. Within closed, private settings, such as industry corporate environments, the dependency on an edge services orchestrator may not pose any limitation. However in a public open access scenario, the organization owning and controlling this orchestration instance may gain a dominating market position due to the dependency of cloudedge services and infrastructure providers on this mediating instance between demand and supply. In this article, peer-to-peer approach for discovering and subscribing to edge infrastructure services is presented, utilizing multicast DNS and peer-to-peer networks. With this approach the necessity of deploying a centralized edge services orchestrator and the associated lock-in effects are avoided. The resulting overlay services model that completely decouples the services layer from the infrastructure layer is well suited to support use cases with loose Quality of Service requirements and limited user equipment mobility.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Peer-to-Peer Approach for Edge Computing Services 1697457440914 10.1109/CloudCom59040.2023.00041 Muhammad Anjum Malik Fachhochschule Dortmund, Germany muhammad.malik@fh-dortmund.de Tobias Pleuger Fachhochschule Dortmund, Germany tobias.pleuger@fh-dortmund.de Stephan Recker Fachhochschule Dortmund, Germany stephan.recker@fh-dortmund.de edge computing multicast DNS peer-to-peer networks Services in the Cloud-Edge continuum and Multi-access Edge Computing have received continuously increasing attention in industry and research. The majority of cloud-edge solutions, specifically those that support ultralow latency services, are based on a centrally deployed edge services orchestrator that allocates resources in all involved cloud-edge components and in the interconnecting infrastructure. Within closed, private settings, such as industry corporate environments, the dependency on an edge services orchestrator may not pose any limitation. However in a public open access scenario, the organization owning and controlling this orchestration instance may gain a dominating market position due to the dependency of cloudedge services and infrastructure providers on this mediating instance between demand and supply. In this article, peer-to-peer approach for discovering and subscribing to edge infrastructure services is presented, utilizing multicast DNS and peer-to-peer networks. With this approach the necessity of deploying a centralized edge services orchestrator and the associated lock-in effects are avoided. The resulting overlay services model that completely decouples the services layer from the infrastructure layer is well suited to support use cases with loose Quality of Service requirements and limited user equipment mobility.",
							"pageNumber": 200,
							"isPageNumberRoman": false
						},
						{
							"eid": "74QIUT1vfDPSbT7tWCYV8U",
							"type": "authorPaper",
							"text": "Traditional vs Federated Learning with Deep Autoencoders: a Study in IoT Intrusion Detection",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a208/398200a208.pdf",
							"extraLocations": [],
							"authorNames": "Marta Catillo (Universit\u00E0 degli Studi del Sannio, Italy), Antonio Pecchia (Universit\u00E0 degli Studi del Sannio, Italy), Umberto Villano (Universit\u00E0 degli Studi del Sannio, Italy)",
							"abstract": "Security of Internet of Things (IoT) devices and networks is a primary concern. Many intrusion detection systems (IDS) proposals in the IoT leverage machine and deep learning algorithms to learn models that can be used to discriminate normal behaviors from intrusions. Due to the dynamicity and scale of modern IoT networks, it is hard to learn and maintain one separate IDS model per device; on the other hand, the Cloud-Edge-IoT architecture allows learning a single IDS model (instead of many separate models). This paper compares two paradigms, i.e., traditional and federated, to learn a single IDS model atop the traffic of different IoT devices. The former assumes the availability of an all-in-one training dataset at a unique learning node; the latter aggregates the outcomes of independent learning procedures executed on individual training datasets hosted by different nodes. The experiments are done with a well-established public benchmark of nine IoT devices and the use of deep autoencoders. In the experiment and dataset at hand, federated learning lead to an increase of the false positive rate of six devices compared to the traditional scenario. Such an increase was balanced by a narrower variability of the false positive rate across all the devices and a mitigation of potential overfitting.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Traditional vs Federated Learning with Deep Autoencoders: a Study in IoT Intrusion Detection 1697621964017 10.1109/CloudCom59040.2023.00042 Marta Catillo Universit\u00E0 degli Studi del Sannio, Italy marta.catillo@unisannio.it Antonio Pecchia Universit\u00E0 degli Studi del Sannio, Italy antonio.pecchia@unisannio.it Umberto Villano Universit\u00E0 degli Studi del Sannio, Italy villano@unisannio.it intrusion detection IoT autoencoder federated learning Security of Internet of Things (IoT) devices and networks is a primary concern. Many intrusion detection systems (IDS) proposals in the IoT leverage machine and deep learning algorithms to learn models that can be used to discriminate normal behaviors from intrusions. Due to the dynamicity and scale of modern IoT networks, it is hard to learn and maintain one separate IDS model per device; on the other hand, the Cloud-Edge-IoT architecture allows learning a single IDS model (instead of many separate models). This paper compares two paradigms, i.e., traditional and federated, to learn a single IDS model atop the traffic of different IoT devices. The former assumes the availability of an all-in-one training dataset at a unique learning node; the latter aggregates the outcomes of independent learning procedures executed on individual training datasets hosted by different nodes. The experiments are done with a well-established public benchmark of nine IoT devices and the use of deep autoencoders. In the experiment and dataset at hand, federated learning lead to an increase of the false positive rate of six devices compared to the traditional scenario. Such an increase was balanced by a narrower variability of the false positive rate across all the devices and a mitigation of potential overfitting.",
							"pageNumber": 208,
							"isPageNumberRoman": false
						},
						{
							"eid": "5S0XocFSHOSNry7gxBhrGm",
							"type": "authorPaper",
							"text": "Decentralized Authentication in Microservice Architectures with SSI and DID in Blockchain",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a216/398200a216.pdf",
							"extraLocations": [],
							"authorNames": "Biagio Boi (University of Salerno, Italy), Christian Esposito (University of Salerno, Italy)",
							"abstract": "Microservice architectures aim at high modularity, reuse, and efficiency of code by structuring applications as a collection of services that are independently deployable, loosely coupled, and organized around business capabilities. As they are starting to be used in sensitive applications, security has started to be a priority, where authentication is one of the first protection means to be offered to developers by those products supporting microservice development. However, the available authentication solutions in these products are highly centralized, leveraging JSON Web Token (JWT) or related standards. This poses a serious issue in meeting the recent privacy legal obligations. In this paper, we propose a solution for integrating a decentralized blockchain-based authentication solution within the context of Istio, which is a service mesh supporting microservice devel-opments. The usage of a Smart Contract, in combination with Decentralized Identifiers (DIDs) and JWT, paves the way for a concrete and fully decentralized revocation system without adding overhead or modification to existing microservices.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Decentralized Authentication in Microservice Architectures with SSI and DID in Blockchain 1697709207762 10.1109/CloudCom59040.2023.00043 Biagio Boi University of Salerno, Italy bboi@unisa.it Christian Esposito University of Salerno, Italy esposito@unisa.it Security Microservices Authentication Digital Identities Blockchain Microservice architectures aim at high modularity, reuse, and efficiency of code by structuring applications as a collection of services that are independently deployable, loosely coupled, and organized around business capabilities. As they are starting to be used in sensitive applications, security has started to be a priority, where authentication is one of the first protection means to be offered to developers by those products supporting microservice development. However, the available authentication solutions in these products are highly centralized, leveraging JSON Web Token (JWT) or related standards. This poses a serious issue in meeting the recent privacy legal obligations. In this paper, we propose a solution for integrating a decentralized blockchain-based authentication solution within the context of Istio, which is a service mesh supporting microservice devel-opments. The usage of a Smart Contract, in combination with Decentralized Identifiers (DIDs) and JWT, paves the way for a concrete and fully decentralized revocation system without adding overhead or modification to existing microservices.",
							"pageNumber": 216,
							"isPageNumberRoman": false
						},
						{
							"eid": "2LG6O7AfCaY1hqi0YGa3WQ",
							"type": "authorPaper",
							"text": "PuppetStack: A tool for building high-availability private cloud infrastructures",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf",
							"extraLocations": [],
							"authorNames": "Fabrizio Messina (University of Catania, Italy), Miriana Russo (University of Catania, Italy), Corrado Santoro (University of Catania, Italy), Federico Fausto Santoro (University of Catania, Italy), Salvatore Riccobene (University of Catania, Italy)",
							"abstract": "As the demand for computational power continues to grow, traditional data processing approaches face limitations, primarily related to physical constraints in materials and processing units. In order to deal with such limitations, the computing industry has turned to multi-core and Symmetric multiprocessing technology, harnessing the combined processing capabilities of multiple processors to spread workloads to improve performance. One of the key strategies in providing computational power for parallel processing is represented by the \u201Cmulti-tenant approach\u201D of Cloud Computing, where multiple tenants can share a huge amount of computational power for the execution of services. Private Cloud is a slightly different approach which ensures more security and control. At the same time, it can provide service continuity and reliability at the system level rather than relying on individual components. In this paper, we discuss the key aspects of cloud computing w.r.t. the existing different service models, particularly focusing on the private Cloud model. To this end, we discuss established technologies for Cloud Computing, particularly the well-known OpenStack. We discuss the key aspects related to the deployment of OpenStack using PuppetStack, which is a software solution we employed for our research. PuppetStack can support the deployment of high-availability private cloud infrastructure.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 PuppetStack: A tool for building high-availability private cloud infrastructures 1697533711235 10.1109/CloudCom59040.2023.00044 Fabrizio Messina University of Catania, Italy fabrizio.messina@unict.it Miriana Russo University of Catania, Italy russo.miriana@studium.unict.it Corrado Santoro University of Catania, Italy corrado.santoro@unict.it Federico Fausto Santoro University of Catania, Italy federico.santoro@unict.it Salvatore Riccobene University of Catania, Italy riccobene@unict.it cloud computing private cloud high availability openstack automation As the demand for computational power continues to grow, traditional data processing approaches face limitations, primarily related to physical constraints in materials and processing units. In order to deal with such limitations, the computing industry has turned to multi-core and Symmetric multiprocessing technology, harnessing the combined processing capabilities of multiple processors to spread workloads to improve performance. One of the key strategies in providing computational power for parallel processing is represented by the \u201Cmulti-tenant approach\u201D of Cloud Computing, where multiple tenants can share a huge amount of computational power for the execution of services. Private Cloud is a slightly different approach which ensures more security and control. At the same time, it can provide service continuity and reliability at the system level rather than relying on individual components. In this paper, we discuss the key aspects of cloud computing w.r.t. the existing different service models, particularly focusing on the private Cloud model. To this end, we discuss established technologies for Cloud Computing, particularly the well-known OpenStack. We discuss the key aspects related to the deployment of OpenStack using PuppetStack, which is a software solution we employed for our research. PuppetStack can support the deployment of high-availability private cloud infrastructure.",
							"pageNumber": 224,
							"isPageNumberRoman": false
						},
						{
							"eid": "fJDXjVm0NOlEDXTQ11mcG",
							"type": "authorPaper",
							"text": "Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a232/398200a232.pdf",
							"extraLocations": [],
							"authorNames": "Gennaro Pio Rimoli (University of Salerno), Daniele Granata (University of Campania Luigi Vanvitelli), Massimo Ficco (University of Salerno)",
							"abstract": "Integration of the Internet of Things (IoT) with cloud computing has accelerated the emergence of a wide range of new applications in different areas, such as manufacturing, supply chains, commercial, engineering, etc. On the other hand, security represents a severe limitation in the adoption of IoT technology in many contexts. Although the cloud paradigm offers and enables flexible adoptions of on-demand services to a variety of IoT applications, due to limited resources of IoT devices and rapid implementation, IoT-cloud-based infrastructures are prone to numerous security vulnerabilities and threats. Therefore, it has become imperative to develop or enhance security strategies. Ideally, security should be built in from the early stages of a new product's development, which often starts as a prototype for internal use and then becomes an end-user product. Therefore, it is necessary to certify the level of security through vulnerability assessments or penetration tests, before the product is made available to the general public. Since both activities are timeand resource-consuming, a semi-automatic penetration testing technique based on the PETIoT framework has been proposed. The suggested approach can be used to evaluate the security of a system that's already in place. It takes into account potential threats, likely attacks, and provides recommendations for improvements. The methodology has been applied to a common IoT case study: the IoT Brick by Babuino Controllers.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study 1697667272234 10.1109/CloudCom59040.2023.00045 Gennaro Pio Rimoli University of Salerno g.rimoli@studenti.unisa.it Daniele Granata University of Campania Luigi Vanvitelli daniele.granata@unicampania.it Massimo Ficco University of Salerno mficco@unisa.it IoT penetration testing tramework IoT cloud service automatic threats model packet capture analysis threat detection engine Integration of the Internet of Things (IoT) with cloud computing has accelerated the emergence of a wide range of new applications in different areas, such as manufacturing, supply chains, commercial, engineering, etc. On the other hand, security represents a severe limitation in the adoption of IoT technology in many contexts. Although the cloud paradigm offers and enables flexible adoptions of on-demand services to a variety of IoT applications, due to limited resources of IoT devices and rapid implementation, IoT-cloud-based infrastructures are prone to numerous security vulnerabilities and threats. Therefore, it has become imperative to develop or enhance security strategies. Ideally, security should be built in from the early stages of a new product's development, which often starts as a prototype for internal use and then becomes an end-user product. Therefore, it is necessary to certify the level of security through vulnerability assessments or penetration tests, before the product is made available to the general public. Since both activities are timeand resource-consuming, a semi-automatic penetration testing technique based on the PETIoT framework has been proposed. The suggested approach can be used to evaluate the security of a system that's already in place. It takes into account potential threats, likely attacks, and provides recommendations for improvements. The methodology has been applied to a common IoT case study: the IoT Brick by Babuino Controllers.",
							"pageNumber": 232,
							"isPageNumberRoman": false
						},
						{
							"eid": "6U67iNmZGFH8XcFC4e9iST",
							"type": "authorPaper",
							"text": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf",
							"extraLocations": [],
							"authorNames": "Jinwei Liu (Florida A&M University, USA), Rui Gong (Mercer University, USA), Wei Dai (Purdue University Northwest, USA), Wei Zheng (Jackson State University, USA), Ying Mao (Fordham University, USA), Wei Zhou (Florida A&M University, USA), Feng Deng (Beijing Information Science & Technology University, China)",
							"abstract": "Heterogeneous workloads composed of long batch jobs and short term jobs are increasingly common in modern datacenters, which poses a challenge to resource scheduling for improving throughput and resource utilization. Achieving high resource utilization and throughput is important to the cloud provider for achieving high revenue. To address this challenge, we propose HCoop, a cooperative and hybrid resource scheduling for high resource utilization and throughput in clouds. HCoop first uses the machine learning algorithm to classify jobs into two categories (long jobs and short jobs) based on the extracted features. Then, it allocates the regular virtual machines (VMs) to tasks of long jobs with higher SLO (Service Level Objective) availability guarantee, and selectively allocates the spot instances to tasks of short jobs for improving the overall resource utilization while ensuring the SLO availability for short jobs. Also, HCoop leverages the complementary of tasks' requirements on different resource types and the heterogeneity of jobs/tasks in job/task size, and it packs complementary tasks whose demands on multiple resource types are complementary to each other and allocates them to a VM to further increase the resource utilization. Extensive experimental results based on a real cluster and Amazon EC2 cloud service show that HCoop achieves high resource utilization and throughput compared to existing strategies.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds 1697741303332 10.1109/CloudCom59040.2023.00046 Jinwei Liu Florida A&M University, USA jinwei.liu@famu.edu Rui Gong Mercer University, USA gong_r@mercer.edu Wei Dai Purdue University Northwest, USA weidai@pnw.edu Wei Zheng Jackson State University, USA wei.zheng@jsums.edu Ying Mao Fordham University, USA ymao41@fordham.edu Wei Zhou Florida A&M University, USA wei.zhou@famu.edu Feng Deng Beijing Information Science & Technology University, China dengfeng@bistu.edu.cn scheduling resource utilization heterogeneity throughput clouds Heterogeneous workloads composed of long batch jobs and short term jobs are increasingly common in modern datacenters, which poses a challenge to resource scheduling for improving throughput and resource utilization. Achieving high resource utilization and throughput is important to the cloud provider for achieving high revenue. To address this challenge, we propose HCoop, a cooperative and hybrid resource scheduling for high resource utilization and throughput in clouds. HCoop first uses the machine learning algorithm to classify jobs into two categories (long jobs and short jobs) based on the extracted features. Then, it allocates the regular virtual machines (VMs) to tasks of long jobs with higher SLO (Service Level Objective) availability guarantee, and selectively allocates the spot instances to tasks of short jobs for improving the overall resource utilization while ensuring the SLO availability for short jobs. Also, HCoop leverages the complementary of tasks' requirements on different resource types and the heterogeneity of jobs/tasks in job/task size, and it packs complementary tasks whose demands on multiple resource types are complementary to each other and allocates them to a VM to further increase the resource utilization. Extensive experimental results based on a real cluster and Amazon EC2 cloud service show that HCoop achieves high resource utilization and throughput compared to existing strategies.",
							"pageNumber": 238,
							"isPageNumberRoman": false
						},
						{
							"eid": "5a2mi8NapzADWIC0VhKwps",
							"type": "authorPaper",
							"text": "Undoing CRDT Operations Automatically",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a246/398200a246.pdf",
							"extraLocations": [],
							"authorNames": "Provakar Mondal (Virginia Tech, USA), Eli Tilevich (Virginia Tech, USA)",
							"abstract": "In a distributed replicated data system, Conflict-free Replicated Data Types (CRDTs) keep data replicas consistent on different nodes, while providing intuitive programming abstractions for accessing and modifying the replicas. Due to user errors, program bugs, or hardware malfunctions, a CRDT can be updated incorrectly, so the effect of the executed CRDT update operations needs to be undone. However, because CRDT libraries rarely include the undo capability, adding it requires modifying source code by hand, a task that is hard to accomplish in a modular and reusable fashion. As a result, programmers end up adding this advanced functionality in an ad-hoc fashion, with the resulting code being hard to understand, maintain, and reuse. To address this problem, this paper presents AUTOUNDO, an automatic approach that generates and actuates undo functionality for existing CRDT libraries, based on simple configurations and without modifying the library code by hand. The configurations specify which CRDT operations undo each other and the conditions that trigger the execution of undo procedures. Based on the configuration, AUTO-UNDO generates and actuates a sequence of update operations that undo the specified updates on a given replica. We have implemented and evaluated AUTO-UNDO in JavaScript, a popular CRDT language, demonstrating our approach's effectiveness, flexibility, and efficiency. Our experiences show that AUTO-UNDO effectively provides the undo capability for CRDT-based applications, thus streamlining the complexity of adding features to distributed programming frameworks.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Undoing CRDT Operations Automatically 1696540785958 10.1109/CloudCom59040.2023.00047 Provakar Mondal Virginia Tech, USA provakar@cs.vt.edu Eli Tilevich Virginia Tech, USA tilevich@cs.vt.edu Distributed Computing, Fault Tolerance, Conflict-free Replicated Data Types, Undo, Code Generation In a distributed replicated data system, Conflict-free Replicated Data Types (CRDTs) keep data replicas consistent on different nodes, while providing intuitive programming abstractions for accessing and modifying the replicas. Due to user errors, program bugs, or hardware malfunctions, a CRDT can be updated incorrectly, so the effect of the executed CRDT update operations needs to be undone. However, because CRDT libraries rarely include the undo capability, adding it requires modifying source code by hand, a task that is hard to accomplish in a modular and reusable fashion. As a result, programmers end up adding this advanced functionality in an ad-hoc fashion, with the resulting code being hard to understand, maintain, and reuse. To address this problem, this paper presents AUTOUNDO, an automatic approach that generates and actuates undo functionality for existing CRDT libraries, based on simple configurations and without modifying the library code by hand. The configurations specify which CRDT operations undo each other and the conditions that trigger the execution of undo procedures. Based on the configuration, AUTO-UNDO generates and actuates a sequence of update operations that undo the specified updates on a given replica. We have implemented and evaluated AUTO-UNDO in JavaScript, a popular CRDT language, demonstrating our approach's effectiveness, flexibility, and efficiency. Our experiences show that AUTO-UNDO effectively provides the undo capability for CRDT-based applications, thus streamlining the complexity of adding features to distributed programming frameworks.",
							"pageNumber": 246,
							"isPageNumberRoman": false
						},
						{
							"eid": "5tBdqMNMza77zuPR6Ex2am",
							"type": "authorPaper",
							"text": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf",
							"extraLocations": [],
							"authorNames": "Bala Subramanyan (Credora Inc., UK), Arne Hollum (Credora Inc., USA), Giovanni Mazzeo (University of Naples \u2019Parthenope\u2019, Italy), Matt Ficke (Credora Inc., USA), Darshan Vaydia (Credora Inc., USA)",
							"abstract": "The ideal TEE service model foresees that data owners load their TEE software in an untrusted platform where the specific processing of the business application can take place inside an enclave, shielded against privileged attackers. In this situation, the data owner needs to trust the TEE hardware vendor only. However, it is very common that the enclave software is offered by a third-party that does not share its source code. Therefore, the service provider must be trusted as well. This is not acceptable when privacy requirements are stringent such as in the fintech ecosystem. In this paper, we propose PRIVATON, an approach based on a dual sandbox strategy leveraging TEE technologies with an embedded WebAssembly sandboxed run-time to compute privacy preserving computations modelled as finite state automatons with verifiable proofs of computations. With PRIVATON, the data owner will have the guarantee that even a malicious TEE developer will not be able to get access to the sensitive data. An implementation of PRIVATON was evaluated in the case study provided by the Credora company who is playing the role of a distributed and privacy-preserving credit oracle in the ecosystem of cryptocurrencies trading.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons 1697622155728 10.1109/CloudCom59040.2023.00048 Bala Subramanyan Credora Inc., UK bala@credora.io Arne Hollum Credora Inc., USA arne@credora.io Giovanni Mazzeo University of Naples \u2019Parthenope\u2019, Italy giovanni.mazzeo@uniparthenope.it Matt Ficke Credora Inc., USA matt@credora.io Darshan Vaydia Credora Inc., USA darshan@credora.io Confidential Computing Trusted Execution Environment WebAssembly Intel SGX Sandbox The ideal TEE service model foresees that data owners load their TEE software in an untrusted platform where the specific processing of the business application can take place inside an enclave, shielded against privileged attackers. In this situation, the data owner needs to trust the TEE hardware vendor only. However, it is very common that the enclave software is offered by a third-party that does not share its source code. Therefore, the service provider must be trusted as well. This is not acceptable when privacy requirements are stringent such as in the fintech ecosystem. In this paper, we propose PRIVATON, an approach based on a dual sandbox strategy leveraging TEE technologies with an embedded WebAssembly sandboxed run-time to compute privacy preserving computations modelled as finite state automatons with verifiable proofs of computations. With PRIVATON, the data owner will have the guarantee that even a malicious TEE developer will not be able to get access to the sensitive data. An implementation of PRIVATON was evaluated in the case study provided by the Credora company who is playing the role of a distributed and privacy-preserving credit oracle in the ecosystem of cryptocurrencies trading.",
							"pageNumber": 252,
							"isPageNumberRoman": false
						},
						{
							"eid": "7eAuuoh6OB6tqgLjvWmmOF",
							"type": "authorPaper",
							"text": "OS\u00B5S: An Open-Source Microservice Prototyping Platform",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a261/398200a261.pdf",
							"extraLocations": [],
							"authorNames": "Lamees M. Al Qassem (Khalifa University, UAE), Thanos Stouraitis (Khalifa University, UAE), Ernesto Damiani (Khalifa University, UAE), Ibrahim M. Elfadel (Khalifa University, UAE)",
							"abstract": "One major advantage of microservice cloud architectures is the agility with which microservices can be replicated to help improve the overall quality of service and meet service-level contracts. Their challenge is to carefully balance the horizontal microservice replicas with the vertical resources of CPU, memory, and IO that are allocated to each microservice. The objective of such balancing act is, of course, to avoid both service bottlenecks and resource wastage. In this paper, we present OS\u00B5S, a new open-source microservice prototyping platform that has been developed and instrumented from the ground up with the objective of collecting fine-grained, non-proprietary metrology on microservice mesh performance. We will illustrate the use of OS\u00B5S for developing and evaluating machine-learning algorithms for the horizontal and vertical autoscaling of microservice architectures. A hybrid algorithm based on decision-tree learning will be implemented on OS\u00B5S and compared with the academic state of the art and existing cloud-provider solutions. The advantages of such algorithm in improving horizontal and vertical resource utilization will be highlighted.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 OS\u00B5S: An Open-Source Microservice Prototyping Platform 1697699981781 10.1109/CloudCom59040.2023.00049 Lamees M. Al Qassem Khalifa University, UAE lamees.alqassem@ku.ac.ae Thanos Stouraitis Khalifa University, UAE thanos.stouraitis@ku.ac.ae Ernesto Damiani Khalifa University, UAE ernesto.damiani@ku.ac.ae Ibrahim M. Elfadel Khalifa University, UAE ibrahim.elfadel@ku.ac.ae Microservices Resource Allocation Containers One major advantage of microservice cloud architectures is the agility with which microservices can be replicated to help improve the overall quality of service and meet service-level contracts. Their challenge is to carefully balance the horizontal microservice replicas with the vertical resources of CPU, memory, and IO that are allocated to each microservice. The objective of such balancing act is, of course, to avoid both service bottlenecks and resource wastage. In this paper, we present OS\u00B5S, a new open-source microservice prototyping platform that has been developed and instrumented from the ground up with the objective of collecting fine-grained, non-proprietary metrology on microservice mesh performance. We will illustrate the use of OS\u00B5S for developing and evaluating machine-learning algorithms for the horizontal and vertical autoscaling of microservice architectures. A hybrid algorithm based on decision-tree learning will be implemented on OS\u00B5S and compared with the academic state of the art and existing cloud-provider solutions. The advantages of such algorithm in improving horizontal and vertical resource utilization will be highlighted.",
							"pageNumber": 261,
							"isPageNumberRoman": false
						}
					],
					"pageNumber": "",
					"isPageNumberRoman": false,
					"chair": null
				},
				{
					"class": "SD",
					"type": "SD_SESSION",
					"title": "Workshop SCC",
					"lineItems": [
						{
							"eid": "3bx08fZPvPdwheGXH2UIPn",
							"type": "authorPaper",
							"text": "Testing Techniques to Assess Impact and Cascading Effects",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf",
							"extraLocations": [],
							"authorNames": "Valeria Vald\u00E9s R\u00EDos (Montimage EURL, France), Ana Rosa Cavalli (Montimage EURL; Institut Politechnique, Telecom SudParis, France), Fatiha Za\u00EFdi (Universit\u00E9 Paris-Saclay, CNRS, ENS Paris-Saclay, Laboratoire M\u00E9thodes Formelles, France), Wissam Mallouli (Montimage EURL, France)",
							"abstract": "The rapid evolution of digital environments and their integration into critical operations of our society have led to substantial challenges in advancing cybersecurity to ensure the proper functioning of these systems . In the face of over-evolving cyber threats and attacks, systems must be equipped with robust mechanisms for protection. In this context, resilience techniques aim to mitigate such treats. However, the evaluation of these techniques is a crucial process, enabling informed decision-making and proactive threat mitigation. This article introduces a methodology based on regression testing for evaluating the impact and cascading effects of resilience strategies. It delves into the methodology\u2019s adaptability across different scenarios and provides insights about the evaluation process.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Testing Techniques to Assess Impact and Cascading Effects 1697649786559 10.1109/CloudCom59040.2023.00050 Valeria Vald\u00E9s R\u00EDos Montimage EURL, France valeria.valdes@montimage.com Ana Rosa Cavalli Montimage EURL; Institut Politechnique, Telecom SudParis, France ana.cavalli@it-sudparis.eu Fatiha Za\u00EFdi Universit\u00E9 Paris-Saclay, CNRS, ENS Paris-Saclay, Laboratoire M\u00E9thodes Formelles, France fatiha.zaidi@universite-paris-saclay.fr Wissam Mallouli Montimage EURL, France wissam.mallouli@montimage.com resilience regression testing moving target defense cloud computing IoT resilience evaluation The rapid evolution of digital environments and their integration into critical operations of our society have led to substantial challenges in advancing cybersecurity to ensure the proper functioning of these systems . In the face of over-evolving cyber threats and attacks, systems must be equipped with robust mechanisms for protection. In this context, resilience techniques aim to mitigate such treats. However, the evaluation of these techniques is a crucial process, enabling informed decision-making and proactive threat mitigation. This article introduces a methodology based on regression testing for evaluating the impact and cascading effects of resilience strategies. It delves into the methodology\u2019s adaptability across different scenarios and provides insights about the evaluation process.",
							"pageNumber": 269,
							"isPageNumberRoman": false
						},
						{
							"eid": "4IyIuwYdEUnkGD2hgjGDOq",
							"type": "authorPaper",
							"text": "Ensuring End-to-End Security in Computing Continuum Exploiting Physical Unclonable Functions",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a273/398200a273.pdf",
							"extraLocations": [],
							"authorNames": "Mario Barbareschi (University of Naples Federico II, Italy), Valentina Casola (University of Naples Federico II, Italy), Daniele Lombardi (University of Naples Federico II, Italy)",
							"abstract": "In recent years, there has been an increase in Cloud Continuum adoption to support Internet of Things applications. Inevitably, such a paradigm introduces novel security challenges, particularly concerning the security of communicating nodes to prevent malicious actors from tampering within the network, and ensuring the confidentiality of sensitive data during transmissions. Traditional security methods often fall short in addressing these issues, especially where network nodes are built upon resource-constrained devices. Consequently, the scientific community has begun exploring the potential of Physical Unclonable Functions (PUFs), which are unique digital identifiers derived from the inherent variability in the manufacturing process of integrated circuits, as a means to enhance security mechanisms at minimal overhead cost. This paper introduces Secure-PHEMAP (S-PHEMAP), a novel and lightweight PUF-based key management scheme designed for end-to-end communications that guarantees authenticity, confidentiality and integrity for pair communications. The proposed scheme builds upon the PHEMAP protocols, inheriting its security properties. S-PHEMAP can be employed in scenarios where both communicating devices embeds a PUF or in situations where only one of them has a PUF. In addition, the paper includes a deployment strategy in a Cloud Continuum domain, by leveraging the Chef automation framework.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Ensuring End-to-End Security in Computing Continuum Exploiting Physical Unclonable Functions 1697728780404 10.1109/CloudCom59040.2023.00051 Mario Barbareschi University of Naples Federico II, Italy mario.barbareschi@unina.it Valentina Casola University of Naples Federico II, Italy casolav@unina.it Daniele Lombardi University of Naples Federico II, Italy daniele.lombardi4@unina.it Security Computing Continuum PUF In recent years, there has been an increase in Cloud Continuum adoption to support Internet of Things applications. Inevitably, such a paradigm introduces novel security challenges, particularly concerning the security of communicating nodes to prevent malicious actors from tampering within the network, and ensuring the confidentiality of sensitive data during transmissions. Traditional security methods often fall short in addressing these issues, especially where network nodes are built upon resource-constrained devices. Consequently, the scientific community has begun exploring the potential of Physical Unclonable Functions (PUFs), which are unique digital identifiers derived from the inherent variability in the manufacturing process of integrated circuits, as a means to enhance security mechanisms at minimal overhead cost. This paper introduces Secure-PHEMAP (S-PHEMAP), a novel and lightweight PUF-based key management scheme designed for end-to-end communications that guarantees authenticity, confidentiality and integrity for pair communications. The proposed scheme builds upon the PHEMAP protocols, inheriting its security properties. S-PHEMAP can be employed in scenarios where both communicating devices embeds a PUF or in situations where only one of them has a PUF. In addition, the paper includes a deployment strategy in a Cloud Continuum domain, by leveraging the Chef automation framework.",
							"pageNumber": 273,
							"isPageNumberRoman": false
						},
						{
							"eid": "1xj27K10qQFg32CgS6CWKr",
							"type": "authorPaper",
							"text": "An Evaluation of Transformer Models for Early Intrusion Detection in Cloud Continuum",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a279/398200a279.pdf",
							"extraLocations": [],
							"authorNames": "Md Mahbub Islam (\u00C5bo Akademi University, Finland), Tanwir Ahmad (\u00C5bo Akademi University, Finland), Dragos Truscan (\u00C5bo Akademi University, Finland)",
							"abstract": "With the increasing popularity of the cloud continuum, the security of different layers and nodes involved has become more relevant than ever. Intrusion detection systems, are one of the main tools to identify and intercept intrusion attacks. Furthermore, identifying the attacks in time, before they are completed, is necessary in order to deploy countermeasures in time and to limit the losses. In this work, we evaluate the use of transformer models for implementing early-detection signature-based detection systems targeted at Cloud Continuum. We implement the approach in the context of our tool for early detection of network intrusions and we evaluate it using the CICIDS2017 dataset and MQTT-IDS-2020. The results show that transformer models are a viable alternative for early-detection systems and this will pave the road for further research on the topic.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 An Evaluation of Transformer Models for Early Intrusion Detection in Cloud Continuum 1697744215967 10.1109/CloudCom59040.2023.00052 Md Mahbub Islam \u00C5bo Akademi University, Finland md.m.islam@abo.fi Tanwir Ahmad \u00C5bo Akademi University, Finland tanwir.ahmad@abo.fi Dragos Truscan \u00C5bo Akademi University, Finland dragos.truscan@abo.fi Intrusion detection systems monitoring deep learning transformer-architecture With the increasing popularity of the cloud continuum, the security of different layers and nodes involved has become more relevant than ever. Intrusion detection systems, are one of the main tools to identify and intercept intrusion attacks. Furthermore, identifying the attacks in time, before they are completed, is necessary in order to deploy countermeasures in time and to limit the losses. In this work, we evaluate the use of transformer models for implementing early-detection signature-based detection systems targeted at Cloud Continuum. We implement the approach in the context of our tool for early detection of network intrusions and we evaluate it using the CICIDS2017 dataset and MQTT-IDS-2020. The results show that transformer models are a viable alternative for early-detection systems and this will pave the road for further research on the topic.",
							"pageNumber": 279,
							"isPageNumberRoman": false
						},
						{
							"eid": "6C7zbnggzxYuxSy8WOBFOT",
							"type": "authorPaper",
							"text": "5G SUCI Catcher: Attack and Detection",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf",
							"extraLocations": [],
							"authorNames": "Lorens Barraud (Thales SIX GTS, France), Francesco Caccavale (Montimage, France), Jean-Baptiste Peyrat (Thales SIX GTS, France), Wissam Mallouli (Montimage, France), V\u00E9ronique Capdevielle (Thales SIX GTS, France), Hicham Khalife (Ericsson, France), Ana Rosa Cavalli (Montimage, France)",
							"abstract": "The deployment of 5G networks opens up new possibilities for communication and connectivity. However, it also introduces new security threats. This paper explores one cyber threat: 5G SUCI Catcher attack. This is a 5G variant of IMSI Catcher involving monitoring and intercepting communications from nearby mobile devices. SUCI Catchers act as fake base stations by exploiting weaknesses of the 5G authentication and encryption protocol. In this paper, SUCI Catcher attack and detection rules are implemented in a 5G experimental environment. The detection solution demonstrates practically the capability to efficiently mitigate the risks associated with this 5G attack.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 5G SUCI Catcher: Attack and Detection 1697784857190 10.1109/CloudCom59040.2023.00053 Lorens Barraud Thales SIX GTS, France lorens.barraud@thalesgroup.com Francesco Caccavale Montimage, France francesco.caccavale@montimage.com Jean-Baptiste Peyrat Thales SIX GTS, France n/a Wissam Mallouli Montimage, France wissam.mallouli@montimage.com V\u00E9ronique Capdevielle Thales SIX GTS, France veronique.capdevielle@thalesgroup.com Hicham Khalife Ericsson, France hicham.khalife@ericsson.com Ana Rosa Cavalli Montimage, France ana.cavalli@montimage.com 5G SUCI Catcher IMSI Catcher detection The deployment of 5G networks opens up new possibilities for communication and connectivity. However, it also introduces new security threats. This paper explores one cyber threat: 5G SUCI Catcher attack. This is a 5G variant of IMSI Catcher involving monitoring and intercepting communications from nearby mobile devices. SUCI Catchers act as fake base stations by exploiting weaknesses of the 5G authentication and encryption protocol. In this paper, SUCI Catcher attack and detection rules are implemented in a 5G experimental environment. The detection solution demonstrates practically the capability to efficiently mitigate the risks associated with this 5G attack.",
							"pageNumber": 285,
							"isPageNumberRoman": false
						},
						{
							"eid": "22XND2tJ2b0v4ISpVxpXLn",
							"type": "authorPaper",
							"text": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf",
							"extraLocations": [],
							"authorNames": "Eider Iturbe (TECNALIA, Basque Research and Technology Alliance (BRTA), Spain; University of the Basque Country, Spain), Erkuden Rios (TECNALIA, Basque Research and Technology Alliance (BRTA), Spain), Nerea Toledo (University of the Basque Country, Spain)",
							"abstract": "The digitalization and smartization of modern digital systems include the implementation and integration of emerging innovative technologies, such as Artificial Intelligence. By incorporating new technologies, the surface attack of the system also expands, and specialized cybersecurity mechanisms and tools are required to counter the potential new threats. This paper introduces a holistic security risk assessment methodology that aims to assist Artificial Intelligence system stakeholders guarantee the correct design and implementation of technical robustness in Artificial Intelligence systems. The methodology is designed to facilitate the automation of the security risk assessment of Artificial Intelligence components together with the rest of the system components. Supporting the methodology, the solution to the automation of Artificial Intelligence risk assessment is also proposed. Both the methodology and the tool will be validated when assessing and treating risks on Artificial Intelligence-based cybersecurity solutions integrated in modern digital industrial systems that leverage emerging technologies such as cloud continuum including Software-defined networking (SDN).",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems 1697736579319 10.1109/CloudCom59040.2023.00054 Eider Iturbe TECNALIA, Basque Research and Technology Alliance (BRTA), Spain; University of the Basque Country, Spain eider.iturbe@tecnalia.com Erkuden Rios TECNALIA, Basque Research and Technology Alliance (BRTA), Spain erkuden.rios@tecnalia.com Nerea Toledo University of the Basque Country, Spain nerea.toledo@ehu.eus Technical robustness Trustworthy Artificial Intelligence Cyber Security Risk Assessment The digitalization and smartization of modern digital systems include the implementation and integration of emerging innovative technologies, such as Artificial Intelligence. By incorporating new technologies, the surface attack of the system also expands, and specialized cybersecurity mechanisms and tools are required to counter the potential new threats. This paper introduces a holistic security risk assessment methodology that aims to assist Artificial Intelligence system stakeholders guarantee the correct design and implementation of technical robustness in Artificial Intelligence systems. The methodology is designed to facilitate the automation of the security risk assessment of Artificial Intelligence components together with the rest of the system components. Supporting the methodology, the solution to the automation of Artificial Intelligence risk assessment is also proposed. Both the methodology and the tool will be validated when assessing and treating risks on Artificial Intelligence-based cybersecurity solutions integrated in modern digital industrial systems that leverage emerging technologies such as cloud continuum including Software-defined networking (SDN).",
							"pageNumber": 291,
							"isPageNumberRoman": false
						},
						{
							"eid": "CgM8SJvLm0xym6QILE6zR",
							"type": "authorPaper",
							"text": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf",
							"extraLocations": [],
							"authorNames": "Phu Nguyen (SINTEF, Norway), Rustem Dautov (SINTEF, Norway), Hui Song (SINTEF, Norway), Angel Rego (TECNALIA, Spain), Eider Iturbe (TECNALIA, Spain), Erkuden Rios (TECNALIA, Spain), Diego Sagasti (TECNALIA, Spain), Gonzalo Nicolas (TECNALIA, Spain), Valeria Vald\u00E9s (Montimage EURL, France), Wissam Mallouli (Montimage EURL, France), Ana Cavalli (Montimage EURL, France), Nicolas Ferry (Universite C\u00F4te d\u2019Azur, France)",
							"abstract": "Current security orchestration and response (SOAR) approaches have primarily focused on specific layers of systems, such as Intrusion Detection Systems, the network layer, or the application layer. We aim to find the gaps in the existing SOAR approaches for IoT/CPS-based systems, especially critical infrastructures, and propose some directions to fill in these gaps. This paper presents a literature survey and future research directions for advancing SOAR towards increased automation and more holistic operation, specially for the cyber-physical security of critical infrastructures. We have found 14 primary SOAR studies and discussed the gaps in general. There is a significant gap when it comes to a comprehensive and systematic approach to SOAR for multi-layered systems using IoT/CPS and considering the computing continuum perspective. To address the gap, we present our on-going work on a framework of multi-layer SOAR decision-making methods and orchestration tools that leverage Reinforcement Learning (RL)-based adaptation intelligence, virtual reality, avatar-human interaction and advanced Cyber Threat Intelligence (CTI) tools. ",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Towards Smarter Security Orchestration and Automatic Response for CPS and IoT 1697711661144 10.1109/CloudCom59040.2023.00055 Phu Nguyen SINTEF, Norway phu.nguyen@sintef.no Rustem Dautov SINTEF, Norway rustem.dautov@sintef.no Hui Song SINTEF, Norway hui.song@sintef.no Angel Rego TECNALIA, Spain angel.rego@tecnalia.com Eider Iturbe TECNALIA, Spain Eider.Iturbe@tecnalia.com Erkuden Rios TECNALIA, Spain Erkuden.Rios@tecnalia.com Diego Sagasti TECNALIA, Spain Diego.Sagasti@tecnalia.com Gonzalo Nicolas TECNALIA, Spain Gonzalo.Nicolas@tecnalia.com Valeria Vald\u00E9s Montimage EURL, France Valeria.Valdes@montimage.com Wissam Mallouli Montimage EURL, France Wissam.Mallouli@montimage.com Ana Cavalli Montimage EURL, France Ana.Cavalli@montimage.com Nicolas Ferry Universite C\u00F4te d\u2019Azur, France Nicolas.Ferry@univ-cotedazur.fr Security Orchestration CPS IoT Machine sLearning VR CTI Current security orchestration and response (SOAR) approaches have primarily focused on specific layers of systems, such as Intrusion Detection Systems, the network layer, or the application layer. We aim to find the gaps in the existing SOAR approaches for IoT/CPS-based systems, especially critical infrastructures, and propose some directions to fill in these gaps. This paper presents a literature survey and future research directions for advancing SOAR towards increased automation and more holistic operation, specially for the cyber-physical security of critical infrastructures. We have found 14 primary SOAR studies and discussed the gaps in general. There is a significant gap when it comes to a comprehensive and systematic approach to SOAR for multi-layered systems using IoT/CPS and considering the computing continuum perspective. To address the gap, we present our on-going work on a framework of multi-layer SOAR decision-making methods and orchestration tools that leverage Reinforcement Learning (RL)-based adaptation intelligence, virtual reality, avatar-human interaction and advanced Cyber Threat Intelligence (CTI) tools.",
							"pageNumber": 298,
							"isPageNumberRoman": false
						},
						{
							"eid": "13evlcYFsudS7ljiqn2P5J",
							"type": "authorPaper",
							"text": "Design and Implementation of Web3-Based E-Commerce Cryptocurrency Payment System",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a303/398200a303.pdf",
							"extraLocations": [],
							"authorNames": "Seung-Seok Lee (Chonnam National University, Republic of Korea), Sang-Joon Lee (Chonnam National University, Republic of Korea)",
							"abstract": "With the rapid development of blockchain technology, it is expected to be combined with Web3.0, leading to increased global interest in a new internet system based on blockchain. As the e-commerce market has grown rapidly, the popularity of cryptocurrency and the opportunities for ecommerce utilizing them are also increasing. However, there\u2019s limited direction on integrating cryptocurrencies into ecommerce, with few studies addressing Web3-based e-commerce includes them. Therefore, this paper proposes a Web3-based ecommerce cryptocurrency payment system. We designed and implemented a DApp that can create packs to sell online and offline contents and transact securely through an escrow account implemented through a smart contract. By presenting a Web3- based e-commerce cryptocurrency payment system, it is expected to promote the revitalization and growth of the e-commerce market and create new business opportunities as it can be used in various industries.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Design and Implementation of Web3-Based E-Commerce Cryptocurrency Payment System 1697699229912 10.1109/CloudCom59040.2023.00056 Seung-Seok Lee Chonnam National University, Republic of Korea sslee4023@jnu.ac.kr Sang-Joon Lee Chonnam National University, Republic of Korea s-lee@jnu.ac.kr Blockchain Web3 Cryptocurrency E-commerce DApp With the rapid development of blockchain technology, it is expected to be combined with Web3.0, leading to increased global interest in a new internet system based on blockchain. As the e-commerce market has grown rapidly, the popularity of cryptocurrency and the opportunities for ecommerce utilizing them are also increasing. However, there\u2019s limited direction on integrating cryptocurrencies into ecommerce, with few studies addressing Web3-based e-commerce includes them. Therefore, this paper proposes a Web3-based ecommerce cryptocurrency payment system. We designed and implemented a DApp that can create packs to sell online and offline contents and transact securely through an escrow account implemented through a smart contract. By presenting a Web3- based e-commerce cryptocurrency payment system, it is expected to promote the revitalization and growth of the e-commerce market and create new business opportunities as it can be used in various industries.",
							"pageNumber": 303,
							"isPageNumberRoman": false
						},
						{
							"eid": "nazEWTEYWJz5SQrt56gWi",
							"type": "authorPaper",
							"text": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf",
							"extraLocations": [],
							"authorNames": "Panagiotis Radoglou-Grammatikis (University of Western Macedonia, Greece; K3Y Ltd, Bulgaria), Elisavet Kioseoglou (University of Western Macedonia, Greece), Dimitrios Asimopoulos (MetaMind Innovations P.C., Greece), Miltiadis Siavvas (Centre for Research and Technology Hellas/Information Technologies Institute, Greece), Ioannis Nanos (Sidroco Holdings Ltd, Cyprus), Thomas Lagkas (International Hellenic University, Greece), Vasileios Argyriou (Kingston University London, UK), Konstantinos E. Psannis (University of Macedonia, Greece), Soririos Goudos (Aristotle University of Thessaloniki, Greece), Panagiotis Sarigiannidis (University of Western Macedonia, Greece)",
							"abstract": "The evolution of cyberattacks has been significantly impacted by the rise of Artificial Intelligence (AI). In particular, AI-driven attacks leverage Machine Learning (ML) and Deep Learning (DL) methods to automate tasks like identifying vulnerabilities, crafting convincing phishing emails, and evading conventional security measures. These cyberattacks can adapt in real time, making them more elusive and challenging to detect. Furthermore, AI has enabled the development of AI-powered malware that can learn and evolve, making it even more dangerous. As AI continues to evolve, both attackers and defenders are engaged in a relentless arms race, with cybersecurity professionals striving to harness AI for threat detection and response while cybercriminals seek to exploit AI's capabilities for their malicious purposes. This ongoing battle underscores the need for proactive and adaptive cybersecurity strategies to mitigate the evolving threats posed by AI-driven cyberattacks. Based on the aforementioned remarks, it is evident that efficient and adaptable countermeasures are necessary. In this paper, we focus our attention on Cyber Threat Intelligence (CTI) mechanisms. CTI is the process of collecting, analysing, and sharing information about potential cybersecurity threats to help organisations proactively defend against cyberattacks. In particular, after providing an overview of the CTI use cases, a brief analysis of existing solutions follows, highlighting the current trends and directions for future work in this research field. ",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends 1697745985747 10.1109/CloudCom59040.2023.00057 Panagiotis Radoglou-Grammatikis University of Western Macedonia, Greece; K3Y Ltd, Bulgaria pradoglou@uowm.gr Elisavet Kioseoglou University of Western Macedonia, Greece ekioseoglou@uowm.gr Dimitrios Asimopoulos MetaMind Innovations P.C., Greece dasimopoulos@metamind.gr Miltiadis Siavvas Centre for Research and Technology Hellas/Information Technologies Institute, Greece siavvasm@iti.gr Ioannis Nanos Sidroco Holdings Ltd, Cyprus inanos@sidroco.com Thomas Lagkas International Hellenic University, Greece tlagkas@cs.ihu.gr Vasileios Argyriou Kingston University London, UK vasileios.argyriou@kingston.ac.uk Konstantinos E. Psannis University of Macedonia, Greece kpsannis@uom.edu.gr Soririos Goudos Aristotle University of Thessaloniki, Greece sgoudo@physics.auth.gr Panagiotis Sarigiannidis University of Western Macedonia, Greece psarigiannidis@uowm.gr Cybersecurity Cyber Threat Intelligence Information Sharing Proactive Defense Survey The evolution of cyberattacks has been significantly impacted by the rise of Artificial Intelligence (AI). In particular, AI-driven attacks leverage Machine Learning (ML) and Deep Learning (DL) methods to automate tasks like identifying vulnerabilities, crafting convincing phishing emails, and evading conventional security measures. These cyberattacks can adapt in real time, making them more elusive and challenging to detect. Furthermore, AI has enabled the development of AI-powered malware that can learn and evolve, making it even more dangerous. As AI continues to evolve, both attackers and defenders are engaged in a relentless arms race, with cybersecurity professionals striving to harness AI for threat detection and response while cybercriminals seek to exploit AI's capabilities for their malicious purposes. This ongoing battle underscores the need for proactive and adaptive cybersecurity strategies to mitigate the evolving threats posed by AI-driven cyberattacks. Based on the aforementioned remarks, it is evident that efficient and adaptable countermeasures are necessary. In this paper, we focus our attention on Cyber Threat Intelligence (CTI) mechanisms. CTI is the process of collecting, analysing, and sharing information about potential cybersecurity threats to help organisations proactively defend against cyberattacks. In particular, after providing an overview of the CTI use cases, a brief analysis of existing solutions follows, highlighting the current trends and directions for future work in this research field.",
							"pageNumber": 309,
							"isPageNumberRoman": false
						},
						{
							"eid": "4lvmJF2nrRQKFBPQyaRdWF",
							"type": "authorPaper",
							"text": "Detecting Security Requirements in GitHub Issues - Novel Dataset and SmallBERT-Based Model",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a315/398200a315.pdf",
							"extraLocations": [],
							"authorNames": "Polina Minina (SOFTEAM, France), Andrey Sadovykh (SOFTEAM, France), Vladimir Ivanov (SOFTEAM, France)",
							"abstract": "Cloud application security initiates with the analysis of security requirements in DevOps. This involves gathering, managing, and tracking requirements within integrated issue-tracking systems found in repositories like GitHub. DevOps offers advantages in cloud app development, such as accelerated deployment, improved collaboration, and enhanced reliability. In DevOps, while many security verification tools are automated, security requirements analysis often relies on manual procedures. User feedback plays a pivotal role in shaping cloud application requirements, and the industry actively seeks automation solutions to expedite development. Prior research has demonstrated the limited performance of conventional NLP models trained on established datasets, such as PROMISE, when employed in the context of GitHub Issues. Recent studies have explored the integration of deep learning, particularly leveraging modern large language models and transfer learning architectures, to address requirements engineering challenges. However, a significant issue persists - the transferability of these models. While these models excel when applied to datasets similar to those they were trained on, their performance often drastically falls when dealing with external domains. In our paper, we introduce an automated method for classifying requirements within issue trackers. This method utilizes a novel dataset comprising 12,000 security and non-security issues collected from open GitHub repositories. We employed a SmallBERT-based model for training and conducted a series of experiments. Our research reaffirms the challenge related to the transferability of NLP models. Simultaneously, our model yields highly promising results when applied to GitHub Issues, even in challenging scenarios involving issues from projects that were not part of the training dataset and structured requirements texts from the PROMISE dataset. In summary, our approach significantly contributes to enhancing DevOps practices within cloud applications by automating security requirements analysis.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Detecting Security Requirements in GitHub Issues - Novel Dataset and SmallBERT-Based Model 1697723019561 10.1109/CloudCom59040.2023.00058 Polina Minina SOFTEAM, France n/a Andrey Sadovykh SOFTEAM, France n/a Vladimir Ivanov SOFTEAM, France n/a Security requirements GitHub Issues NLP Classification Dataset Machine Learning Deep learning BERT Cloud application security initiates with the analysis of security requirements in DevOps. This involves gathering, managing, and tracking requirements within integrated issue-tracking systems found in repositories like GitHub. DevOps offers advantages in cloud app development, such as accelerated deployment, improved collaboration, and enhanced reliability. In DevOps, while many security verification tools are automated, security requirements analysis often relies on manual procedures. User feedback plays a pivotal role in shaping cloud application requirements, and the industry actively seeks automation solutions to expedite development. Prior research has demonstrated the limited performance of conventional NLP models trained on established datasets, such as PROMISE, when employed in the context of GitHub Issues. Recent studies have explored the integration of deep learning, particularly leveraging modern large language models and transfer learning architectures, to address requirements engineering challenges. However, a significant issue persists - the transferability of these models. While these models excel when applied to datasets similar to those they were trained on, their performance often drastically falls when dealing with external domains. In our paper, we introduce an automated method for classifying requirements within issue trackers. This method utilizes a novel dataset comprising 12,000 security and non-security issues collected from open GitHub repositories. We employed a SmallBERT-based model for training and conducted a series of experiments. Our research reaffirms the challenge related to the transferability of NLP models. Simultaneously, our model yields highly promising results when applied to GitHub Issues, even in challenging scenarios involving issues from projects that were not part of the training dataset and structured requirements texts from the PROMISE dataset. In summary, our approach significantly contributes to enhancing DevOps practices within cloud applications by automating security requirements analysis.",
							"pageNumber": 315,
							"isPageNumberRoman": false
						},
						{
							"eid": "7fU3WkFXx7TC6iHKXJtw3P",
							"type": "authorPaper",
							"text": "Software Bill of Materials in Critical Infrastructure",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf",
							"extraLocations": [],
							"authorNames": "Lars Andreassen Jaatun (NTNU, Norway), Silje Marie S\u00F8rlien (NTNU, Norway), Ravishankar Borgaonkar (SINTEF Digital, Norway), Steve Taylor (University of Southampton, UK), Martin Gilje Jaatun (SINTEF Digital, Norway; University of Stavanger, Norway)",
							"abstract": "Critical infrastructure today is comprised of cyber-physical systems, and therefore also vulnerable to cyber threats. Many of these threats come from within, through malicious code in software updates or bugs that can be exploited. Further exacerbating the issue is the fact that most software suppliers in critical infrastructure are developing proprietary systems and giving out minimal information about the composition of their software products. With the US introduction of a Software Bill of Materials (SBOM) requirement in federal information systems, they are better prepared to deal with cyber incidents. This article examines regulations regarding software in critical infrastructure, and whether there is any benefit to mandating SBOMs in critical infrastructure.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Software Bill of Materials in Critical Infrastructure 1697721013671 10.1109/CloudCom59040.2023.00059 Lars Andreassen Jaatun NTNU, Norway n/a Silje Marie S\u00F8rlien NTNU, Norway n/a Ravishankar Borgaonkar SINTEF Digital, Norway n/a Steve Taylor University of Southampton, UK n/a Martin Gilje Jaatun SINTEF Digital, Norway; University of Stavanger, Norway n/a SBOM Critical Commmunication Cyber Security Software Security Critical infrastructure today is comprised of cyber-physical systems, and therefore also vulnerable to cyber threats. Many of these threats come from within, through malicious code in software updates or bugs that can be exploited. Further exacerbating the issue is the fact that most software suppliers in critical infrastructure are developing proprietary systems and giving out minimal information about the composition of their software products. With the US introduction of a Software Bill of Materials (SBOM) requirement in federal information systems, they are better prepared to deal with cyber incidents. This article examines regulations regarding software in critical infrastructure, and whether there is any benefit to mandating SBOMs in critical infrastructure.",
							"pageNumber": 319,
							"isPageNumberRoman": false
						}
					],
					"pageNumber": "",
					"isPageNumberRoman": false,
					"chair": null
				},
				{
					"class": "SD",
					"type": "SD_SESSION",
					"title": "Workshop IAC",
					"lineItems": [
						{
							"eid": "62ItUKk8IfYbhwbl4NtMV2",
							"type": "authorPaper",
							"text": "Increasing Robustness of Blockchain Peer-to-Peer Networks with Alternative Peer Initialization",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a325/398200a325.pdf",
							"extraLocations": [],
							"authorNames": "Bernadet Klein Wassink (University of Amsterdam, Netherlands), Zhiming Zhao (University of Amsterdam, Netherlands)",
							"abstract": "In this paper, we identified the most important vulnerabilities of a peer-to-peer (P2P) network in a blockchain and proposed an algorithm for adding new peers to an existing network in order to increase robustness. We determined the main vulnerabilities and their detection metrics by means of current literature. They can be categorized by topological characteristics, network resource statistics, the local characteristics of the neigh-bors set per peer, and implementation details of various parts of the blockchain. Based on topological metrics, we set forth an algorithm for adding new peers into an optimal position in order to increase overall robustness. Her we define robustness as the functionality and stability of the blockchain. A proof of concept, comparing it to random connections showed no indication of a better robustness, as measured by chain creation and its stability, over time. However future works is needed to determine efficacy of this algorithm and other ways of using metrics to initialize peer connections.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Increasing Robustness of Blockchain Peer-to-Peer Networks with Alternative Peer Initialization 1697557280678 10.1109/CloudCom59040.2023.00060 Bernadet Klein Wassink University of Amsterdam, Netherlands bernadet.klein.wassink@gmail.com Zhiming Zhao University of Amsterdam, Netherlands z.zhao@uva.nl networks peer-to-peer blockchain robustness security In this paper, we identified the most important vulnerabilities of a peer-to-peer (P2P) network in a blockchain and proposed an algorithm for adding new peers to an existing network in order to increase robustness. We determined the main vulnerabilities and their detection metrics by means of current literature. They can be categorized by topological characteristics, network resource statistics, the local characteristics of the neigh-bors set per peer, and implementation details of various parts of the blockchain. Based on topological metrics, we set forth an algorithm for adding new peers into an optimal position in order to increase overall robustness. Her we define robustness as the functionality and stability of the blockchain. A proof of concept, comparing it to random connections showed no indication of a better robustness, as measured by chain creation and its stability, over time. However future works is needed to determine efficacy of this algorithm and other ways of using metrics to initialize peer connections.",
							"pageNumber": 325,
							"isPageNumberRoman": false
						},
						{
							"eid": "6GOANxOn2Bw4rToRXPBGK4",
							"type": "authorPaper",
							"text": "Decoding NFT Market Dynamics with Data",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a333/398200a333.pdf",
							"extraLocations": [],
							"authorNames": "Smruti Inamdar (VU/ University of Amsterdam, Netherlands), Zhiming Zhao (University of Amsterdam, LifeWatch VLIC, the Netherlands)",
							"abstract": "Non-Fungible Tokens (NFTs) are a developing area in the market of digital assets. NFTs represent digital or realworld items like artwork, gaming collectibles and real estate. We aim to study the daily working of NFT market and its interaction with cryptocurrency (Ether and Bitcoin) and search interest. Our approach involves identification of models encompassing both global and local feature importance. Various regression methods are utilized to determine the feature importance and select the predictive features effectively. Moreover, this study explores the relationship between search interest and weekly NFT sales and vice versa, to comprehend how public interest impacts the NFT market. Lastly, anomalies in daily sales are detected and analysed using STL Decomposition and SHAPely. The study reveals that intrinsic sales attributes and trade profits drive daily NFT sales, with positive sentiment significantly impacting Ethereum volatility and NFT sales. External factors like NFT supply, Ether price, and trade profits also influence anomalies. Positive sentiment significantly shapes crypto and NFT market dynamics.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Decoding NFT Market Dynamics with Data 1697652716726 10.1109/CloudCom59040.2023.00061 Smruti Inamdar VU/ University of Amsterdam, Netherlands s.inamdar@student.vu.nl Zhiming Zhao University of Amsterdam, LifeWatch VLIC, the Netherlands z.zhao@uva.nl Non Fungible Tokens Feature Importance Anomaly Detection Time Series Analysis Non-Fungible Tokens (NFTs) are a developing area in the market of digital assets. NFTs represent digital or realworld items like artwork, gaming collectibles and real estate. We aim to study the daily working of NFT market and its interaction with cryptocurrency (Ether and Bitcoin) and search interest. Our approach involves identification of models encompassing both global and local feature importance. Various regression methods are utilized to determine the feature importance and select the predictive features effectively. Moreover, this study explores the relationship between search interest and weekly NFT sales and vice versa, to comprehend how public interest impacts the NFT market. Lastly, anomalies in daily sales are detected and analysed using STL Decomposition and SHAPely. The study reveals that intrinsic sales attributes and trade profits drive daily NFT sales, with positive sentiment significantly impacting Ethereum volatility and NFT sales. External factors like NFT supply, Ether price, and trade profits also influence anomalies. Positive sentiment significantly shapes crypto and NFT market dynamics.",
							"pageNumber": 333,
							"isPageNumberRoman": false
						},
						{
							"eid": "4x0HUZfZByf92cXrComaDF",
							"type": "authorPaper",
							"text": "Flexible and Secure Code Deployment in Federated Learning using Large Language Models: Prompt Engineering to Enhance Malicious Code Detection",
							"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a341/398200a341.pdf",
							"extraLocations": [],
							"authorNames": "Jungwon Seo (University of Stavanger, Norway), Nan Zhang (University of Stavanger, Norway), Chunming Rong (University of Stavanger, Norway)",
							"abstract": "Federated Learning is a machine learning methodology that emphasizes data privacy, involving minimal interaction with each other's systems, primarily exchanging model parameters. However, this approach can introduce challenges in system development and operation because it inherently faces statistical and system heterogeneity issues. The diverse data storage formats and system environments across clients limit the feasibility of training with a uniform code. To distribute a new code to each environment, active participation of Federated Learning collaborators is necessary, incurring time and cost. Moreover, it impedes adopting modern automated development and deployment paradigms such as DevOps or MLOps. This study investigates how Large Language Models (LLMs) can automatically tailor a single code to individual client environments in heterogeneous scenarios without human intervention. Moreover, to enable the automatic adaptation of the deployed code for conducting new experiments within the system, it is imperative to assess the presence of potentially malicious code that could jeopardize data security. To address this challenge, we introduce a novel prompt engineering technique to enhance LLMs' detection capabilities, thereby bolstering our ability to detect malicious code effectively.",
							"searchText": "2023 IEEE International Conference on Cloud Computing Technology and Science (CloudCom) CloudCom 2023 Flexible and Secure Code Deployment in Federated Learning using Large Language Models: Prompt Engineering to Enhance Malicious Code Detection 1697537451517 10.1109/CloudCom59040.2023.00062 Jungwon Seo University of Stavanger, Norway jungwon.seo@uis.no Nan Zhang University of Stavanger, Norway nan.zhang@uis.no Chunming Rong University of Stavanger, Norway chunming.rong@uis.no Software Engineering Federated Learning Large Language Models Security Federated Learning is a machine learning methodology that emphasizes data privacy, involving minimal interaction with each other's systems, primarily exchanging model parameters. However, this approach can introduce challenges in system development and operation because it inherently faces statistical and system heterogeneity issues. The diverse data storage formats and system environments across clients limit the feasibility of training with a uniform code. To distribute a new code to each environment, active participation of Federated Learning collaborators is necessary, incurring time and cost. Moreover, it impedes adopting modern automated development and deployment paradigms such as DevOps or MLOps. This study investigates how Large Language Models (LLMs) can automatically tailor a single code to individual client environments in heterogeneous scenarios without human intervention. Moreover, to enable the automatic adaptation of the deployed code for conducting new experiments within the system, it is imperative to assess the presence of potentially malicious code that could jeopardize data security. To address this challenge, we introduce a novel prompt engineering technique to enhance LLMs' detection capabilities, thereby bolstering our ability to detect malicious code effectively.",
							"pageNumber": 341,
							"isPageNumberRoman": false
						}
					],
					"pageNumber": "",
					"isPageNumberRoman": false,
					"chair": null
				}
			]
		}
	],
	"authors": [
		{
			"author": {
				"givenName": "Marco",
				"surname": "Abbadini"
			},
			"authorName": "Abbadini, Marco",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Tanwir",
				"surname": "Ahmad"
			},
			"authorName": "Ahmad, Tanwir",
			"articleRefs": [
				{
					"pageNumber": 279,
					"articleName": "An Evaluation of Transformer Models for Early Intrusion Detection in Cloud Continuum",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a279/398200a279.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Lorena-Alina",
				"surname": "Alexandru"
			},
			"authorName": "Alexandru, Lorena-Alina",
			"articleRefs": [
				{
					"pageNumber": 58,
					"articleName": "A Blockchain-Based Online Trading Platform: TrustTrade",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a058/398200a058.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Gayashan",
				"surname": "Amarasinghe"
			},
			"authorName": "Amarasinghe, Gayashan",
			"articleRefs": [
				{
					"pageNumber": 131,
					"articleName": "Cost-Optimized Scheduling for Microservices in Kubernetes",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a131/398200a131.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Vasileios",
				"surname": "Argyriou"
			},
			"authorName": "Argyriou, Vasileios",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Sugunakumar",
				"surname": "Arunan"
			},
			"authorName": "Arunan, Sugunakumar",
			"articleRefs": [
				{
					"pageNumber": 131,
					"articleName": "Cost-Optimized Scheduling for Microservices in Kubernetes",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a131/398200a131.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Dimitrios",
				"surname": "Asimopoulos"
			},
			"authorName": "Asimopoulos, Dimitrios",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Mario",
				"surname": "Barbareschi"
			},
			"authorName": "Barbareschi, Mario",
			"articleRefs": [
				{
					"pageNumber": 273,
					"articleName": "Ensuring End-to-End Security in Computing Continuum Exploiting Physical Unclonable Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a273/398200a273.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Lorens",
				"surname": "Barraud"
			},
			"authorName": "Barraud, Lorens",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Vitor E.",
				"surname": "Batista"
			},
			"authorName": "Batista, Vitor E.",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jo\u00E3o H. F.",
				"surname": "Battisti"
			},
			"authorName": "Battisti, Jo\u00E3o H. F.",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Roberto",
				"surname": "Beraldi"
			},
			"authorName": "Beraldi, Roberto",
			"articleRefs": [
				{
					"pageNumber": 42,
					"articleName": "A Load Balancing Algorithm For Long-Life Green Edge Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a042/398200a042.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Diana Gratiela",
				"surname": "Berbecaru"
			},
			"authorName": "Berbecaru, Diana Gratiela",
			"articleRefs": [
				{
					"pageNumber": 91,
					"articleName": "A Flexible Trust Manager for Remote Attestation in Heterogeneous Critical Infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a091/398200a091.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Michele",
				"surname": "Beretta"
			},
			"authorName": "Beretta, Michele",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Josep L.",
				"surname": "Berral"
			},
			"authorName": "Berral, Josep L.",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "David Fern\u00E1ndez",
				"surname": "Blanco"
			},
			"authorName": "Blanco, David Fern\u00E1ndez",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Biagio",
				"surname": "Boi"
			},
			"authorName": "Boi, Biagio",
			"articleRefs": [
				{
					"pageNumber": 216,
					"articleName": "Decentralized Authentication in Microservice Architectures with SSI and DID in Blockchain",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a216/398200a216.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ravishankar",
				"surname": "Borgaonkar"
			},
			"authorName": "Borgaonkar, Ravishankar",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Enrico",
				"surname": "Bravi"
			},
			"authorName": "Bravi, Enrico",
			"articleRefs": [
				{
					"pageNumber": 91,
					"articleName": "A Flexible Trust Manager for Remote Attestation in Heterogeneous Critical Infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a091/398200a091.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Andrey",
				"surname": "Brito"
			},
			"authorName": "Brito, Andrey",
			"articleRefs": [
				{
					"pageNumber": 169,
					"articleName": "Triad: Trusted Timestamps in Untrusted Environments",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a169/398200a169.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Thang",
				"surname": "Bui"
			},
			"authorName": "Bui, Thang",
			"articleRefs": [
				{
					"pageNumber": 1,
					"articleName": "Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a001/398200a001.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Francesco",
				"surname": "Caccavale"
			},
			"authorName": "Caccavale, Francesco",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Minjie",
				"surname": "Cai"
			},
			"authorName": "Cai, Minjie",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "V\u00E9ronique",
				"surname": "Capdevielle"
			},
			"authorName": "Capdevielle, V\u00E9ronique",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Xavier de Carn\u00E9 de",
				"surname": "Carnavalet"
			},
			"authorName": "Carnavalet, Xavier de Carn\u00E9 de",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Valentina",
				"surname": "Casola"
			},
			"authorName": "Casola, Valentina",
			"articleRefs": [
				{
					"pageNumber": 273,
					"articleName": "Ensuring End-to-End Security in Computing Continuum Exploiting Physical Unclonable Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a273/398200a273.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Marta",
				"surname": "Catillo"
			},
			"authorName": "Catillo, Marta",
			"articleRefs": [
				{
					"pageNumber": 208,
					"articleName": "Traditional vs Federated Learning with Deep Autoencoders: a Study in IoT Intrusion Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a208/398200a208.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ana",
				"surname": "Cavalli"
			},
			"authorName": "Cavalli, Ana",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ana Rosa",
				"surname": "Cavalli"
			},
			"authorName": "Cavalli, Ana Rosa",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				},
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Kerem",
				"surname": "Celik"
			},
			"authorName": "Celik, Kerem",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Yifan",
				"surname": "Chen"
			},
			"authorName": "Chen, Yifan",
			"articleRefs": [
				{
					"pageNumber": 52,
					"articleName": "Enhancing Mobile Privacy and Security: A Face Skin Patch-Based Anti-Spoofing Approach",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a052/398200a052.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Donald",
				"surname": "Chinn"
			},
			"authorName": "Chinn, Donald",
			"articleRefs": [
				{
					"pageNumber": 193,
					"articleName": "Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a193/398200a193.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Paul",
				"surname": "Chow"
			},
			"authorName": "Chow, Paul",
			"articleRefs": [
				{
					"pageNumber": 82,
					"articleName": "A Lightweight Routing Layer using a Reliable Link-Layer Protocol",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a082/398200a082.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Robert",
				"surname": "Cordingly"
			},
			"authorName": "Cordingly, Robert",
			"articleRefs": [
				{
					"pageNumber": 193,
					"articleName": "Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a193/398200a193.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Wei",
				"surname": "Dai"
			},
			"authorName": "Dai, Wei",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ernesto",
				"surname": "Damiani"
			},
			"authorName": "Damiani, Ernesto",
			"articleRefs": [
				{
					"pageNumber": 261,
					"articleName": "OS\u00B5S: An Open-Source Microservice Prototyping Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a261/398200a261.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Rustem",
				"surname": "Dautov"
			},
			"authorName": "Dautov, Rustem",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Feng",
				"surname": "Deng"
			},
			"authorName": "Deng, Feng",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Marios D.",
				"surname": "Dikaiakos"
			},
			"authorName": "Dikaiakos, Marios D.",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "L\u00FAcia M. A.",
				"surname": "Drummond"
			},
			"authorName": "Drummond, L\u00FAcia M. A.",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ibrahim M.",
				"surname": "Elfadel"
			},
			"authorName": "Elfadel, Ibrahim M.",
			"articleRefs": [
				{
					"pageNumber": 261,
					"articleName": "OS\u00B5S: An Open-Source Microservice Prototyping Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a261/398200a261.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Shereen",
				"surname": "ElSayed"
			},
			"authorName": "ElSayed, Shereen",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Paal E.",
				"surname": "Engelstad"
			},
			"authorName": "Engelstad, Paal E.",
			"articleRefs": [
				{
					"pageNumber": 18,
					"articleName": "Introducing TinyKVM for High-Performance CDN Edge Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a018/398200a018.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "M\u0103d\u0103lina",
				"surname": "Era\u015Fcu"
			},
			"authorName": "Era\u015Fcu, M\u0103d\u0103lina",
			"articleRefs": [
				{
					"pageNumber": 10,
					"articleName": "SAGE - A Tool for Optimal Deployments in Kubernetes Clusters",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a010/398200a010.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Christian",
				"surname": "Esposito"
			},
			"authorName": "Esposito, Christian",
			"articleRefs": [
				{
					"pageNumber": 216,
					"articleName": "Decentralized Authentication in Microservice Architectures with SSI and DID in Blockchain",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a216/398200a216.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Rui",
				"surname": "Esteves"
			},
			"authorName": "Esteves, Rui",
			"articleRefs": [
				{
					"pageNumber": 76,
					"articleName": "Recommendation Engine for Optimal Spark Delta Tables Partitioning",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a076/398200a076.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Paulo J. B.",
				"surname": "Estrela"
			},
			"authorName": "Estrela, Paulo J. B.",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Dario",
				"surname": "Facchinetti"
			},
			"authorName": "Facchinetti, Dario",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Georgios",
				"surname": "Fatouros"
			},
			"authorName": "Fatouros, Georgios",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Gabriel",
				"surname": "Fernandez"
			},
			"authorName": "Fernandez, Gabriel",
			"articleRefs": [
				{
					"pageNumber": 169,
					"articleName": "Triad: Trusted Timestamps in Untrusted Environments",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a169/398200a169.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Nicolas",
				"surname": "Ferry"
			},
			"authorName": "Ferry, Nicolas",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Christof",
				"surname": "Fetzer"
			},
			"authorName": "Fetzer, Christof",
			"articleRefs": [
				{
					"pageNumber": 169,
					"articleName": "Triad: Trusted Timestamps in Untrusted Environments",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a169/398200a169.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Massimo",
				"surname": "Ficco"
			},
			"authorName": "Ficco, Massimo",
			"articleRefs": [
				{
					"pageNumber": 232,
					"articleName": "Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a232/398200a232.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Matt",
				"surname": "Ficke"
			},
			"authorName": "Ficke, Matt",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Michael",
				"surname": "Filippakis"
			},
			"authorName": "Filippakis, Michael",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ola Andr\u00E8",
				"surname": "Flotve"
			},
			"authorName": "Flotve, Ola Andr\u00E8",
			"articleRefs": [
				{
					"pageNumber": 76,
					"articleName": "Recommendation Engine for Optimal Spark Delta Tables Partitioning",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a076/398200a076.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jing",
				"surname": "Fu"
			},
			"authorName": "Fu, Jing",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Hend K.",
				"surname": "Gedawy"
			},
			"authorName": "Gedawy, Hend K.",
			"articleRefs": [
				{
					"pageNumber": 1,
					"articleName": "Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a001/398200a001.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Joanna",
				"surname": "Georgiou"
			},
			"authorName": "Georgiou, Joanna",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Rui",
				"surname": "Gong"
			},
			"authorName": "Gong, Rui",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Soririos",
				"surname": "Goudos"
			},
			"authorName": "Goudos, Soririos",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Daniele",
				"surname": "Granata"
			},
			"authorName": "Granata, Daniele",
			"articleRefs": [
				{
					"pageNumber": 232,
					"articleName": "Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a232/398200a232.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Qiushi",
				"surname": "Guo"
			},
			"authorName": "Guo, Qiushi",
			"articleRefs": [
				{
					"pageNumber": 52,
					"articleName": "Enhancing Mobile Privacy and Security: A Face Skin Patch-Based Anti-Spoofing Approach",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a052/398200a052.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Khaled A.",
				"surname": "Harras"
			},
			"authorName": "Harras, Khaled A.",
			"articleRefs": [
				{
					"pageNumber": 1,
					"articleName": "Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a001/398200a001.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Aitor Hernandez",
				"surname": "Herranz"
			},
			"authorName": "Herranz, Aitor Hernandez",
			"articleRefs": [
				{
					"pageNumber": 63,
					"articleName": "Enabling 5G QoS Configuration Capabilities for IoT Applications on Container Orchestration Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a063/398200a063.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Arne",
				"surname": "Hollum"
			},
			"authorName": "Hollum, Arne",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Asif",
				"surname": "Imran"
			},
			"authorName": "Imran, Asif",
			"articleRefs": [
				{
					"pageNumber": 69,
					"articleName": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Smruti",
				"surname": "Inamdar"
			},
			"authorName": "Inamdar, Smruti",
			"articleRefs": [
				{
					"pageNumber": 333,
					"articleName": "Decoding NFT Market Dynamics with Data",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a333/398200a333.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Md Mahbub",
				"surname": "Islam"
			},
			"authorName": "Islam, Md Mahbub",
			"articleRefs": [
				{
					"pageNumber": 279,
					"articleName": "An Evaluation of Transformer Models for Early Intrusion Detection in Cloud Continuum",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a279/398200a279.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Eider",
				"surname": "Iturbe"
			},
			"authorName": "Iturbe, Eider",
			"articleRefs": [
				{
					"pageNumber": 291,
					"articleName": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf"
				},
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Vladimir",
				"surname": "Ivanov"
			},
			"authorName": "Ivanov, Vladimir",
			"articleRefs": [
				{
					"pageNumber": 315,
					"articleName": "Detecting Security Requirements in GitHub Issues - Novel Dataset and SmallBERT-Based Model",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a315/398200a315.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Lars Andreassen",
				"surname": "Jaatun"
			},
			"authorName": "Jaatun, Lars Andreassen",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Martin Gilje",
				"surname": "Jaatun"
			},
			"authorName": "Jaatun, Martin Gilje",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "H\u00E5vard Moe",
				"surname": "Jacobsen"
			},
			"authorName": "Jacobsen, H\u00E5vard Moe",
			"articleRefs": [
				{
					"pageNumber": 76,
					"articleName": "Recommendation Engine for Optimal Spark Delta Tables Partitioning",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a076/398200a076.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Hicham",
				"surname": "Khalife"
			},
			"authorName": "Khalife, Hicham",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Elisavet",
				"surname": "Kioseoglou"
			},
			"authorName": "Kioseoglou, Elisavet",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Tevfik",
				"surname": "Kosar"
			},
			"authorName": "Kosar, Tevfik",
			"articleRefs": [
				{
					"pageNumber": 69,
					"articleName": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Guilherme P.",
				"surname": "Koslovski"
			},
			"authorName": "Koslovski, Guilherme P.",
			"articleRefs": [
				{
					"pageNumber": 115,
					"articleName": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf"
				},
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Georgios",
				"surname": "Kousiouris"
			},
			"authorName": "Kousiouris, Georgios",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Diego",
				"surname": "Kreutz"
			},
			"authorName": "Kreutz, Diego",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Chandra",
				"surname": "Krintz"
			},
			"authorName": "Krintz, Chandra",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Dimosthenis",
				"surname": "Kyriazis"
			},
			"authorName": "Kyriazis, Dimosthenis",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Thomas",
				"surname": "Lagkas"
			},
			"authorName": "Lagkas, Thomas",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Che-Rung",
				"surname": "Lee"
			},
			"authorName": "Lee, Che-Rung",
			"articleRefs": [
				{
					"pageNumber": 34,
					"articleName": "GSLAC: GPU Software Level Access Control for Information Isolation on Cloud Platforms",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a034/398200a034.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Sang-Joon",
				"surname": "Lee"
			},
			"authorName": "Lee, Sang-Joon",
			"articleRefs": [
				{
					"pageNumber": 303,
					"articleName": "Design and Implementation of Web3-Based E-Commerce Cryptocurrency Payment System",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a303/398200a303.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Seung-Seok",
				"surname": "Lee"
			},
			"authorName": "Lee, Seung-Seok",
			"articleRefs": [
				{
					"pageNumber": 303,
					"articleName": "Design and Implementation of Web3-Based E-Commerce Cryptocurrency Payment System",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a303/398200a303.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Chia-Chang",
				"surname": "Li"
			},
			"authorName": "Li, Chia-Chang",
			"articleRefs": [
				{
					"pageNumber": 34,
					"articleName": "GSLAC: GPU Software Level Access Control for Information Isolation on Cloud Platforms",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a034/398200a034.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Shisha",
				"surname": "Liao"
			},
			"authorName": "Liao, Shisha",
			"articleRefs": [
				{
					"pageNumber": 52,
					"articleName": "Enhancing Mobile Privacy and Security: A Face Skin Patch-Based Anti-Spoofing Approach",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a052/398200a052.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Trista",
				"surname": "Lin"
			},
			"authorName": "Lin, Trista",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Antonio",
				"surname": "Lioy"
			},
			"authorName": "Lioy, Antonio",
			"articleRefs": [
				{
					"pageNumber": 91,
					"articleName": "A Flexible Trust Manager for Remote Attestation in Heterogeneous Critical Infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a091/398200a091.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jinwei",
				"surname": "Liu"
			},
			"authorName": "Liu, Jinwei",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Yu",
				"surname": "Liu"
			},
			"authorName": "Liu, Yu",
			"articleRefs": [
				{
					"pageNumber": 63,
					"articleName": "Enabling 5G QoS Configuration Capabilities for IoT Applications on Container Orchestration Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a063/398200a063.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Wes",
				"surname": "Lloyd"
			},
			"authorName": "Lloyd, Wes",
			"articleRefs": [
				{
					"pageNumber": 193,
					"articleName": "Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a193/398200a193.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Daniele",
				"surname": "Lombardi"
			},
			"authorName": "Lombardi, Daniele",
			"articleRefs": [
				{
					"pageNumber": 273,
					"articleName": "Ensuring End-to-End Security in Computing Continuum Exploiting Physical Unclonable Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a273/398200a273.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Vlad-Ioan",
				"surname": "Luca"
			},
			"authorName": "Luca, Vlad-Ioan",
			"articleRefs": [
				{
					"pageNumber": 10,
					"articleName": "SAGE - A Tool for Optimal Deployments in Kubernetes Clusters",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a010/398200a010.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Samridhi",
				"surname": "Maheshwari"
			},
			"authorName": "Maheshwari, Samridhi",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Georgios",
				"surname": "Makridis"
			},
			"authorName": "Makridis, Georgios",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Muhammad Anjum",
				"surname": "Malik"
			},
			"authorName": "Malik, Muhammad Anjum",
			"articleRefs": [
				{
					"pageNumber": 200,
					"articleName": "Peer-to-Peer Approach for Edge Computing Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a200/398200a200.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Renzo Q.",
				"surname": "Malini"
			},
			"authorName": "Malini, Renzo Q.",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Wissam",
				"surname": "Mallouli"
			},
			"authorName": "Mallouli, Wissam",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				},
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				},
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ying",
				"surname": "Mao"
			},
			"authorName": "Mao, Ying",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Marco A.",
				"surname": "Marques"
			},
			"authorName": "Marques, Marco A.",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ibrahim",
				"surname": "Matta"
			},
			"authorName": "Matta, Ibrahim",
			"articleRefs": [
				{
					"pageNumber": 26,
					"articleName": "Inverse Response Time Ratio Scheduler: Optimizing Throughput and Response Time for Serverless Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a026/398200a026.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Gabriele Proietti",
				"surname": "Mattia"
			},
			"authorName": "Mattia, Gabriele Proietti",
			"articleRefs": [
				{
					"pageNumber": 42,
					"articleName": "A Load Balancing Algorithm For Long-Life Green Edge Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a042/398200a042.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Giovanni",
				"surname": "Mazzeo"
			},
			"authorName": "Mazzeo, Giovanni",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Fabrizio",
				"surname": "Messina"
			},
			"authorName": "Messina, Fabrizio",
			"articleRefs": [
				{
					"pageNumber": 224,
					"articleName": "PuppetStack: A tool for building high-availability private cloud infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Charles C.",
				"surname": "Miers"
			},
			"authorName": "Miers, Charles C.",
			"articleRefs": [
				{
					"pageNumber": 115,
					"articleName": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf"
				},
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Polina",
				"surname": "Minina"
			},
			"authorName": "Minina, Polina",
			"articleRefs": [
				{
					"pageNumber": 315,
					"articleName": "Detecting Security Requirements in GitHub Issues - Novel Dataset and SmallBERT-Based Model",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a315/398200a315.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Di",
				"surname": "Mo"
			},
			"authorName": "Mo, Di",
			"articleRefs": [
				{
					"pageNumber": 193,
					"articleName": "Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a193/398200a193.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Markus",
				"surname": "Mock"
			},
			"authorName": "Mock, Markus",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Sameer Ahmed",
				"surname": "Mohamed"
			},
			"authorName": "Mohamed, Sameer Ahmed",
			"articleRefs": [
				{
					"pageNumber": 69,
					"articleName": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Provakar",
				"surname": "Mondal"
			},
			"authorName": "Mondal, Provakar",
			"articleRefs": [
				{
					"pageNumber": 246,
					"articleName": "Undoing CRDT Operations Automatically",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a246/398200a246.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Mina",
				"surname": "Morcos"
			},
			"authorName": "Morcos, Mina",
			"articleRefs": [
				{
					"pageNumber": 26,
					"articleName": "Inverse Response Time Ratio Scheduler: Optimizing Throughput and Response Time for Serverless Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a026/398200a026.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Fr\u00E9d\u00E9ric Le",
				"surname": "Mou\u00EBl"
			},
			"authorName": "Mou\u00EBl, Fr\u00E9d\u00E9ric Le",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Ioannis",
				"surname": "Nanos"
			},
			"authorName": "Nanos, Ioannis",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Phu",
				"surname": "Nguyen"
			},
			"authorName": "Nguyen, Phu",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Gonzalo",
				"surname": "Nicolas"
			},
			"authorName": "Nicolas, Gonzalo",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Gianluca",
				"surname": "Oldani"
			},
			"authorName": "Oldani, Gianluca",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Diego E.G.C. de",
				"surname": "Oliveira"
			},
			"authorName": "Oliveira, Diego E.G.C. de",
			"articleRefs": [
				{
					"pageNumber": 115,
					"articleName": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "George",
				"surname": "Pallis"
			},
			"authorName": "Pallis, George",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Stefano",
				"surname": "Paraboschi"
			},
			"authorName": "Paraboschi, Stefano",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Antonio",
				"surname": "Pecchia"
			},
			"authorName": "Pecchia, Antonio",
			"articleRefs": [
				{
					"pageNumber": 208,
					"articleName": "Traditional vs Federated Learning with Deep Autoencoders: a Study in IoT Intrusion Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a208/398200a208.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Indika",
				"surname": "Perera"
			},
			"authorName": "Perera, Indika",
			"articleRefs": [
				{
					"pageNumber": 131,
					"articleName": "Cost-Optimized Scheduling for Microservices in Kubernetes",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a131/398200a131.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jean-Baptiste",
				"surname": "Peyrat"
			},
			"authorName": "Peyrat, Jean-Baptiste",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Maur\u00EDcio A.",
				"surname": "Pillon"
			},
			"authorName": "Pillon, Maur\u00EDcio A.",
			"articleRefs": [
				{
					"pageNumber": 115,
					"articleName": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf"
				},
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Tobias",
				"surname": "Pleuger"
			},
			"authorName": "Pleuger, Tobias",
			"articleRefs": [
				{
					"pageNumber": 200,
					"articleName": "Peer-to-Peer Approach for Edge Computing Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a200/398200a200.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Felipe A.",
				"surname": "Portella"
			},
			"authorName": "Portella, Felipe A.",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Konstantinos E.",
				"surname": "Psannis"
			},
			"authorName": "Psannis, Konstantinos E.",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Lamees M. Al",
				"surname": "Qassem"
			},
			"authorName": "Qassem, Lamees M. Al",
			"articleRefs": [
				{
					"pageNumber": 261,
					"articleName": "OS\u00B5S: An Open-Source Microservice Prototyping Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a261/398200a261.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Panagiotis",
				"surname": "Radoglou-Grammatikis"
			},
			"authorName": "Radoglou-Grammatikis, Panagiotis",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Stephan",
				"surname": "Recker"
			},
			"authorName": "Recker, Stephan",
			"articleRefs": [
				{
					"pageNumber": 200,
					"articleName": "Peer-to-Peer Approach for Edge Computing Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a200/398200a200.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Angel",
				"surname": "Rego"
			},
			"authorName": "Rego, Angel",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Amir",
				"surname": "Rekik"
			},
			"authorName": "Rekik, Amir",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Salvatore",
				"surname": "Riccobene"
			},
			"authorName": "Riccobene, Salvatore",
			"articleRefs": [
				{
					"pageNumber": 224,
					"articleName": "PuppetStack: A tool for building high-availability private cloud infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Gennaro Pio",
				"surname": "Rimoli"
			},
			"authorName": "Rimoli, Gennaro Pio",
			"articleRefs": [
				{
					"pageNumber": 232,
					"articleName": "Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a232/398200a232.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Valeria Vald\u00E9s",
				"surname": "R\u00EDos"
			},
			"authorName": "R\u00EDos, Valeria Vald\u00E9s",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Erkuden",
				"surname": "Rios"
			},
			"authorName": "Rios, Erkuden",
			"articleRefs": [
				{
					"pageNumber": 291,
					"articleName": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf"
				},
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Chunming",
				"surname": "Rong"
			},
			"authorName": "Rong, Chunming",
			"articleRefs": [
				{
					"pageNumber": 341,
					"articleName": "Flexible and Secure Code Deployment in Federated Learning using Large Language Models: Prompt Engineering to Enhance Malicious Code Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a341/398200a341.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Matthew",
				"surname": "Rossi"
			},
			"authorName": "Rossi, Matthew",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Miriana",
				"surname": "Russo"
			},
			"authorName": "Russo, Miriana",
			"articleRefs": [
				{
					"pageNumber": 224,
					"articleName": "PuppetStack: A tool for building high-availability private cloud infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Andrey",
				"surname": "Sadovykh"
			},
			"authorName": "Sadovykh, Andrey",
			"articleRefs": [
				{
					"pageNumber": 315,
					"articleName": "Detecting Security Requirements in GitHub Issues - Novel Dataset and SmallBERT-Based Model",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a315/398200a315.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Diego",
				"surname": "Sagasti"
			},
			"authorName": "Sagasti, Diego",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Corrado",
				"surname": "Santoro"
			},
			"authorName": "Santoro, Corrado",
			"articleRefs": [
				{
					"pageNumber": 224,
					"articleName": "PuppetStack: A tool for building high-availability private cloud infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Federico Fausto",
				"surname": "Santoro"
			},
			"authorName": "Santoro, Federico Fausto",
			"articleRefs": [
				{
					"pageNumber": 224,
					"articleName": "PuppetStack: A tool for building high-availability private cloud infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Panagiotis",
				"surname": "Sarigiannidis"
			},
			"authorName": "Sarigiannidis, Panagiotis",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Marlon H.",
				"surname": "Schweigert"
			},
			"authorName": "Schweigert, Marlon H.",
			"articleRefs": [
				{
					"pageNumber": 115,
					"articleName": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jungwon",
				"surname": "Seo"
			},
			"authorName": "Seo, Jungwon",
			"articleRefs": [
				{
					"pageNumber": 341,
					"articleName": "Flexible and Secure Code Deployment in Federated Learning using Large Language Models: Prompt Engineering to Enhance Malicious Code Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a341/398200a341.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Raj Narendra",
				"surname": "Shah"
			},
			"authorName": "Shah, Raj Narendra",
			"articleRefs": [
				{
					"pageNumber": 69,
					"articleName": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Qianfeng",
				"surname": "Shen"
			},
			"authorName": "Shen, Qianfeng",
			"articleRefs": [
				{
					"pageNumber": 82,
					"articleName": "A Lightweight Routing Layer using a Reliable Link-Layer Protocol",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a082/398200a082.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Miltiadis",
				"surname": "Siavvas"
			},
			"authorName": "Siavvas, Miltiadis",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Marcos",
				"surname": "Simpl\u00EDcio"
			},
			"authorName": "Simpl\u00EDcio, Marcos",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "John",
				"surname": "Soldatos"
			},
			"authorName": "Soldatos, John",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Hui",
				"surname": "Song"
			},
			"authorName": "Song, Hui",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Silje Marie",
				"surname": "S\u00F8rlien"
			},
			"authorName": "S\u00F8rlien, Silje Marie",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Marius",
				"surname": "Storheim"
			},
			"authorName": "Storheim, Marius",
			"articleRefs": [
				{
					"pageNumber": 58,
					"articleName": "A Blockchain-Based Online Trading Platform: TrustTrade",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a058/398200a058.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Thanos",
				"surname": "Stouraitis"
			},
			"authorName": "Stouraitis, Thanos",
			"articleRefs": [
				{
					"pageNumber": 261,
					"articleName": "OS\u00B5S: An Open-Source Microservice Prototyping Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a261/398200a261.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Bala",
				"surname": "Subramanyan"
			},
			"authorName": "Subramanyan, Bala",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Moysis",
				"surname": "Symeonides"
			},
			"authorName": "Symeonides, Moysis",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Temoor",
				"surname": "Tanveer"
			},
			"authorName": "Tanveer, Temoor",
			"articleRefs": [
				{
					"pageNumber": 1,
					"articleName": "Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a001/398200a001.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Steve",
				"surname": "Taylor"
			},
			"authorName": "Taylor, Steve",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Luan",
				"surname": "Teylo"
			},
			"authorName": "Teylo, Luan",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Eli",
				"surname": "Tilevich"
			},
			"authorName": "Tilevich, Eli",
			"articleRefs": [
				{
					"pageNumber": 246,
					"articleName": "Undoing CRDT Operations Automatically",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a246/398200a246.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Nerea",
				"surname": "Toledo"
			},
			"authorName": "Toledo, Nerea",
			"articleRefs": [
				{
					"pageNumber": 291,
					"articleName": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Demetris",
				"surname": "Trihinas"
			},
			"authorName": "Trihinas, Demetris",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Dragos",
				"surname": "Truscan"
			},
			"authorName": "Truscan, Dragos",
			"articleRefs": [
				{
					"pageNumber": 279,
					"articleName": "An Evaluation of Transformer Models for Early Intrusion Detection in Cloud Continuum",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a279/398200a279.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Valeria",
				"surname": "Vald\u00E9s"
			},
			"authorName": "Vald\u00E9s, Valeria",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Darshan",
				"surname": "Vaydia"
			},
			"authorName": "Vaydia, Darshan",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Umberto",
				"surname": "Villano"
			},
			"authorName": "Villano, Umberto",
			"articleRefs": [
				{
					"pageNumber": 208,
					"articleName": "Traditional vs Federated Learning with Deep Autoencoders: a Study in IoT Intrusion Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a208/398200a208.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Alf-Andr\u00E9",
				"surname": "Walla"
			},
			"authorName": "Walla, Alf-Andr\u00E9",
			"articleRefs": [
				{
					"pageNumber": 18,
					"articleName": "Introducing TinyKVM for High-Performance CDN Edge Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a018/398200a018.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Bernadet Klein",
				"surname": "Wassink"
			},
			"authorName": "Wassink, Bernadet Klein",
			"articleRefs": [
				{
					"pageNumber": 325,
					"articleName": "Increasing Robustness of Blockchain Peer-to-Peer Networks with Alternative Peer Initialization",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a325/398200a325.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Rich",
				"surname": "Wolski"
			},
			"authorName": "Wolski, Rich",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jingjin",
				"surname": "Wu"
			},
			"authorName": "Wu, Jingjin",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Po-Cheng",
				"surname": "Wu"
			},
			"authorName": "Wu, Po-Cheng",
			"articleRefs": [
				{
					"pageNumber": 34,
					"articleName": "GSLAC: GPU Software Level Access Control for Information Isolation on Cloud Platforms",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a034/398200a034.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Jiahe",
				"surname": "Xu"
			},
			"authorName": "Xu, Jiahe",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Guang",
				"surname": "Yang"
			},
			"authorName": "Yang, Guang",
			"articleRefs": [
				{
					"pageNumber": 58,
					"articleName": "A Blockchain-Based Online Trading Platform: TrustTrade",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a058/398200a058.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Fatiha",
				"surname": "Za\u00EFdi"
			},
			"authorName": "Za\u00EFdi, Fatiha",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Mengyuan",
				"surname": "Zhang"
			},
			"authorName": "Zhang, Mengyuan",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Nan",
				"surname": "Zhang"
			},
			"authorName": "Zhang, Nan",
			"articleRefs": [
				{
					"pageNumber": 341,
					"articleName": "Flexible and Secure Code Deployment in Federated Learning using Large Language Models: Prompt Engineering to Enhance Malicious Code Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a341/398200a341.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Siqi",
				"surname": "Zhang"
			},
			"authorName": "Zhang, Siqi",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Lianying",
				"surname": "Zhao"
			},
			"authorName": "Zhao, Lianying",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Zhiming",
				"surname": "Zhao"
			},
			"authorName": "Zhao, Zhiming",
			"articleRefs": [
				{
					"pageNumber": 325,
					"articleName": "Increasing Robustness of Blockchain Peer-to-Peer Networks with Alternative Peer Initialization",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a325/398200a325.pdf"
				},
				{
					"pageNumber": 333,
					"articleName": "Decoding NFT Market Dynamics with Data",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a333/398200a333.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Wei",
				"surname": "Zheng"
			},
			"authorName": "Zheng, Wei",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Wei",
				"surname": "Zhou"
			},
			"authorName": "Zhou, Wei",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"author": {
				"givenName": "Moshe",
				"surname": "Zukerman"
			},
			"authorName": "Zukerman, Moshe",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		}
	],
	"affiliations": [
		{
			"affiliation": "\u00C5bo Akademi University, Finland",
			"articleRefs": [
				{
					"pageNumber": 279,
					"articleName": "An Evaluation of Transformer Models for Early Intrusion Detection in Cloud Continuum",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a279/398200a279.pdf"
				}
			]
		},
		{
			"affiliation": "AI Lab, China Merchants Bank",
			"articleRefs": [
				{
					"pageNumber": 52,
					"articleName": "Enhancing Mobile Privacy and Security: A Face Skin Patch-Based Anti-Spoofing Approach",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a052/398200a052.pdf"
				}
			]
		},
		{
			"affiliation": "Aristotle University of Thessaloniki, Greece",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "Beijing Information Science & Technology University, China",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"affiliation": "BNU-HKBU United International College, P.R. China",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		},
		{
			"affiliation": "Boston University",
			"articleRefs": [
				{
					"pageNumber": 26,
					"articleName": "Inverse Response Time Ratio Scheduler: Optimizing Throughput and Response Time for Serverless Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a026/398200a026.pdf"
				}
			]
		},
		{
			"affiliation": "California State University, USA",
			"articleRefs": [
				{
					"pageNumber": 69,
					"articleName": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf"
				}
			]
		},
		{
			"affiliation": "Carleton University, Canada",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"affiliation": "Carnegie Mellon University",
			"articleRefs": [
				{
					"pageNumber": 1,
					"articleName": "Bridging the Chasm Between Ideal and Realistic Federated Learning: A Measurements Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a001/398200a001.pdf"
				}
			]
		},
		{
			"affiliation": "Centre for Research and Technology Hellas/Information Technologies Institute, Greece",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "Chonnam National University, Republic of Korea",
			"articleRefs": [
				{
					"pageNumber": 303,
					"articleName": "Design and Implementation of Web3-Based E-Commerce Cryptocurrency Payment System",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a303/398200a303.pdf"
				}
			]
		},
		{
			"affiliation": "City University of Hong Kong, P.R. China",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		},
		{
			"affiliation": "Credora Inc., UK",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"affiliation": "Credora Inc., USA",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"affiliation": "Ericsson, France",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"affiliation": "Ericsson Research, Sweden",
			"articleRefs": [
				{
					"pageNumber": 63,
					"articleName": "Enabling 5G QoS Configuration Capabilities for IoT Applications on Container Orchestration Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a063/398200a063.pdf"
				}
			]
		},
		{
			"affiliation": "Fachhochschule Dortmund, Germany",
			"articleRefs": [
				{
					"pageNumber": 200,
					"articleName": "Peer-to-Peer Approach for Edge Computing Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a200/398200a200.pdf"
				}
			]
		},
		{
			"affiliation": "Federal University of Pampa (Unipampa), Brazil",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"affiliation": "Florida A&M University, USA",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"affiliation": "Fordham University, USA",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"affiliation": "Graduate Program in Applied Computing (PPGCAP) \u2013 Santa Catarina State University (UDESC), Brazil",
			"articleRefs": [
				{
					"pageNumber": 115,
					"articleName": "Experimental Analysis of Microservices Architectures for Hosting Cloud-Based Massive Multiplayer Online Role-Playing Game (MMORPG)",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a115/398200a115.pdf"
				}
			]
		},
		{
			"affiliation": "Harokopio University, Greece",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"affiliation": "HAW Landshut, Germany",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"affiliation": "Innov-Acts Ltd, Cyprus",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"affiliation": "Institut National de Recherche en Informatique et en Automatique (Inria), France; Universidade Federal Fluminense (UFF), Brazil",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"affiliation": "International Hellenic University, Greece",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "Jackson State University, USA",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"affiliation": "Khalifa University, UAE",
			"articleRefs": [
				{
					"pageNumber": 261,
					"articleName": "OS\u00B5S: An Open-Source Microservice Prototyping Platform",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a261/398200a261.pdf"
				}
			]
		},
		{
			"affiliation": "Kingston University London, UK",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "Mercer University, USA",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"affiliation": "MetaMind Innovations P.C., Greece",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "Montimage EURL, France",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				},
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"affiliation": "Montimage EURL; Institut Politechnique, Telecom SudParis, France",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				}
			]
		},
		{
			"affiliation": "Montimage, France",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"affiliation": "National Tsing Hua University, Taiwan",
			"articleRefs": [
				{
					"pageNumber": 34,
					"articleName": "GSLAC: GPU Software Level Access Control for Information Isolation on Cloud Platforms",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a034/398200a034.pdf"
				}
			]
		},
		{
			"affiliation": "NTNU, Norway",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"affiliation": "Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"affiliation": "Petr\u00F3leo Brasileiro S.A. (PETROBRAS), Brazil; Barcelona Supercomputing Center (BSC), Spain; Universitat Polit\u00E8cnica de Catalunya (UPC), Spain",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"affiliation": "Politecnico di Torino, Italy",
			"articleRefs": [
				{
					"pageNumber": 91,
					"articleName": "A Flexible Trust Manager for Remote Attestation in Heterogeneous Critical Infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a091/398200a091.pdf"
				}
			]
		},
		{
			"affiliation": "Purdue University Northwest, USA",
			"articleRefs": [
				{
					"pageNumber": 238,
					"articleName": "HCoop: A Cooperative and Hybrid Resource Scheduling for Heterogeneous Jobs in Clouds",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a238/398200a238.pdf"
				}
			]
		},
		{
			"affiliation": "RMIT University, Australia",
			"articleRefs": [
				{
					"pageNumber": 147,
					"articleName": "Energy-Efficient Offloading in Edge Slicing with Non-Linear Power Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a147/398200a147.pdf"
				}
			]
		},
		{
			"affiliation": "Santa Catarina State University (UDESC), Brazil",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"affiliation": "Sapienza University of Rome, Italy",
			"articleRefs": [
				{
					"pageNumber": 42,
					"articleName": "A Load Balancing Algorithm For Long-Life Green Edge Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a042/398200a042.pdf"
				}
			]
		},
		{
			"affiliation": "Sidroco Holdings Ltd, Cyprus",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "SINTEF Digital, Norway",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"affiliation": "SINTEF Digital, Norway; University of Stavanger, Norway",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"affiliation": "SINTEF, Norway",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"affiliation": "SOFTEAM, France",
			"articleRefs": [
				{
					"pageNumber": 315,
					"articleName": "Detecting Security Requirements in GitHub Issues - Novel Dataset and SmallBERT-Based Model",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a315/398200a315.pdf"
				}
			]
		},
		{
			"affiliation": "STELLANTIS, France",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"affiliation": "TECNALIA, Basque Research and Technology Alliance (BRTA), Spain",
			"articleRefs": [
				{
					"pageNumber": 291,
					"articleName": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf"
				}
			]
		},
		{
			"affiliation": "TECNALIA, Basque Research and Technology Alliance (BRTA), Spain; University of the Basque Country, Spain",
			"articleRefs": [
				{
					"pageNumber": 291,
					"articleName": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf"
				}
			]
		},
		{
			"affiliation": "TECNALIA, Spain",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"affiliation": "Thales SIX GTS, France",
			"articleRefs": [
				{
					"pageNumber": 285,
					"articleName": "5G SUCI Catcher: Attack and Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a285/398200a285.pdf"
				}
			]
		},
		{
			"affiliation": "The Hong Kong Polytechnic University, China",
			"articleRefs": [
				{
					"pageNumber": 185,
					"articleName": "The Flaw Within: Identifying CVSS Score Discrepancies in the NVD",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a185/398200a185.pdf"
				}
			]
		},
		{
			"affiliation": "TU-Dresden, Germany",
			"articleRefs": [
				{
					"pageNumber": 169,
					"articleName": "Triad: Trusted Timestamps in Untrusted Environments",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a169/398200a169.pdf"
				}
			]
		},
		{
			"affiliation": "UCSB Computer Science Department, USA",
			"articleRefs": [
				{
					"pageNumber": 107,
					"articleName": "Depot: Dependency-Eager Platform of Transformations",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a107/398200a107.pdf"
				}
			]
		},
		{
			"affiliation": "UFCG, Brazil",
			"articleRefs": [
				{
					"pageNumber": 169,
					"articleName": "Triad: Trusted Timestamps in Untrusted Environments",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a169/398200a169.pdf"
				}
			]
		},
		{
			"affiliation": "Universidade de S\u00E3o Paulo (USP), Brazil",
			"articleRefs": [
				{
					"pageNumber": 155,
					"articleName": "Performance Analysis of the Raft Consensus Algorithm on Hyperledger Fabric and Ethereum on Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a155/398200a155.pdf"
				}
			]
		},
		{
			"affiliation": "Universidade Federal Fluminense (UFF), Brazil",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"affiliation": "Universit\u00E0 degli Studi del Sannio, Italy",
			"articleRefs": [
				{
					"pageNumber": 208,
					"articleName": "Traditional vs Federated Learning with Deep Autoencoders: a Study in IoT Intrusion Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a208/398200a208.pdf"
				}
			]
		},
		{
			"affiliation": "Universit\u00E0 degli Studi di Bergamo, Italy",
			"articleRefs": [
				{
					"pageNumber": 139,
					"articleName": "Lightweight Cloud Application Sandboxing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a139/398200a139.pdf"
				}
			]
		},
		{
			"affiliation": "Universitat Polit\u00E8cnica de Catalunya (UPC), Spain; Barcelona Supercomputing Center (BSC), Spain",
			"articleRefs": [
				{
					"pageNumber": 99,
					"articleName": "MScheduler: Leveraging Spot Instances for High-Performance Reservoir Simulation in the Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a099/398200a099.pdf"
				}
			]
		},
		{
			"affiliation": "Universite C\u00F4te d\u2019Azur, France",
			"articleRefs": [
				{
					"pageNumber": 298,
					"articleName": "Towards Smarter Security Orchestration and Automatic Response for CPS and IoT",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a298/398200a298.pdf"
				}
			]
		},
		{
			"affiliation": "Universit\u00E9 Paris-Saclay, CNRS, ENS Paris-Saclay, Laboratoire M\u00E9thodes Formelles, France",
			"articleRefs": [
				{
					"pageNumber": 269,
					"articleName": "Testing Techniques to Assess Impact and Cascading Effects",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a269/398200a269.pdf"
				}
			]
		},
		{
			"affiliation": "University at Buffalo, USA",
			"articleRefs": [
				{
					"pageNumber": 69,
					"articleName": "CloudScent: A Model for Code Smell Analysis in Open-Source Cloud",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a069/398200a069.pdf"
				}
			]
		},
		{
			"affiliation": "University of Amsterdam, LifeWatch VLIC, the Netherlands",
			"articleRefs": [
				{
					"pageNumber": 333,
					"articleName": "Decoding NFT Market Dynamics with Data",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a333/398200a333.pdf"
				}
			]
		},
		{
			"affiliation": "University of Amsterdam, Netherlands",
			"articleRefs": [
				{
					"pageNumber": 325,
					"articleName": "Increasing Robustness of Blockchain Peer-to-Peer Networks with Alternative Peer Initialization",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a325/398200a325.pdf"
				}
			]
		},
		{
			"affiliation": "University of Campania Luigi Vanvitelli",
			"articleRefs": [
				{
					"pageNumber": 232,
					"articleName": "Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a232/398200a232.pdf"
				}
			]
		},
		{
			"affiliation": "University of Catania, Italy",
			"articleRefs": [
				{
					"pageNumber": 224,
					"articleName": "PuppetStack: A tool for building high-availability private cloud infrastructures",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a224/398200a224.pdf"
				}
			]
		},
		{
			"affiliation": "University of Cyprus",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"affiliation": "University of Macedonia, Greece",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "University of Moratuwa, Sri Lanka",
			"articleRefs": [
				{
					"pageNumber": 131,
					"articleName": "Cost-Optimized Scheduling for Microservices in Kubernetes",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a131/398200a131.pdf"
				}
			]
		},
		{
			"affiliation": "University of Naples Federico II, Italy",
			"articleRefs": [
				{
					"pageNumber": 273,
					"articleName": "Ensuring End-to-End Security in Computing Continuum Exploiting Physical Unclonable Functions",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a273/398200a273.pdf"
				}
			]
		},
		{
			"affiliation": "University of Naples \u2019Parthenope\u2019, Italy",
			"articleRefs": [
				{
					"pageNumber": 252,
					"articleName": "Enabling Trusted TEE-as-a-Service Models with Privacy Preserving Automatons",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a252/398200a252.pdf"
				}
			]
		},
		{
			"affiliation": "University of Nicosia",
			"articleRefs": [
				{
					"pageNumber": 161,
					"articleName": "Energy-Aware Streaming Analytics Job Scheduling for Edge Computing",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a161/398200a161.pdf"
				}
			]
		},
		{
			"affiliation": "University of Oslo (UiO), Norway",
			"articleRefs": [
				{
					"pageNumber": 18,
					"articleName": "Introducing TinyKVM for High-Performance CDN Edge Services",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a018/398200a018.pdf"
				}
			]
		},
		{
			"affiliation": "University of Piraeus, Greece",
			"articleRefs": [
				{
					"pageNumber": 177,
					"articleName": "Enhanced Runtime-Adaptable Routing for Serverless Functions Based on Performance and Cost Tradeoffs in Hybrid Cloud Settings",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a177/398200a177.pdf"
				}
			]
		},
		{
			"affiliation": "University of Salerno",
			"articleRefs": [
				{
					"pageNumber": 232,
					"articleName": "Semi-Automatic PenTest Methodology Based on Threat-Model: The IoT Brick Case Study",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a232/398200a232.pdf"
				}
			]
		},
		{
			"affiliation": "University of Salerno, Italy",
			"articleRefs": [
				{
					"pageNumber": 216,
					"articleName": "Decentralized Authentication in Microservice Architectures with SSI and DID in Blockchain",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a216/398200a216.pdf"
				}
			]
		},
		{
			"affiliation": "University of Southampton, UK",
			"articleRefs": [
				{
					"pageNumber": 319,
					"articleName": "Software Bill of Materials in Critical Infrastructure",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a319/398200a319.pdf"
				}
			]
		},
		{
			"affiliation": "University of Stavanger, Norway",
			"articleRefs": [
				{
					"pageNumber": 76,
					"articleName": "Recommendation Engine for Optimal Spark Delta Tables Partitioning",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a076/398200a076.pdf"
				},
				{
					"pageNumber": 341,
					"articleName": "Flexible and Secure Code Deployment in Federated Learning using Large Language Models: Prompt Engineering to Enhance Malicious Code Detection",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a341/398200a341.pdf"
				}
			]
		},
		{
			"affiliation": "University of the Basque Country, Spain",
			"articleRefs": [
				{
					"pageNumber": 291,
					"articleName": "Towards Trustworthy Artificial Intelligence: Security Risk Assessment Methodology for Artificial Intelligence Systems",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a291/398200a291.pdf"
				}
			]
		},
		{
			"affiliation": "University of Toronto, Canada",
			"articleRefs": [
				{
					"pageNumber": 82,
					"articleName": "A Lightweight Routing Layer using a Reliable Link-Layer Protocol",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a082/398200a082.pdf"
				}
			]
		},
		{
			"affiliation": "University of Washington, USA",
			"articleRefs": [
				{
					"pageNumber": 193,
					"articleName": "Addressing Serverless Computing Vendor Lock-In through Cloud Service Abstraction",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a193/398200a193.pdf"
				}
			]
		},
		{
			"affiliation": "University of Western Macedonia, Greece",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "University of Western Macedonia, Greece; K3Y Ltd, Bulgaria",
			"articleRefs": [
				{
					"pageNumber": 309,
					"articleName": "Surveying Cyber Threat Intelligence and Collaboration: A Concise Analysis of Current Landscape and Trends",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a309/398200a309.pdf"
				}
			]
		},
		{
			"affiliation": "Univ Lyon, INSA LYON, Inria, CITI, France",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"affiliation": "Univ Lyon, INSA LYON, Inria, CITI, France; STELLANTIS, France",
			"articleRefs": [
				{
					"pageNumber": 123,
					"articleName": "Can Software Containerisation Fit The Car On-Board Systems ?",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a123/398200a123.pdf"
				}
			]
		},
		{
			"affiliation": "Virginia Tech, USA",
			"articleRefs": [
				{
					"pageNumber": 246,
					"articleName": "Undoing CRDT Operations Automatically",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a246/398200a246.pdf"
				}
			]
		},
		{
			"affiliation": "VU/ University of Amsterdam, Netherlands",
			"articleRefs": [
				{
					"pageNumber": 333,
					"articleName": "Decoding NFT Market Dynamics with Data",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a333/398200a333.pdf"
				}
			]
		},
		{
			"affiliation": "Western Norway University of Applied Sciences, Norway",
			"articleRefs": [
				{
					"pageNumber": 58,
					"articleName": "A Blockchain-Based Online Trading Platform: TrustTrade",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a058/398200a058.pdf"
				}
			]
		},
		{
			"affiliation": "West University of Timisoara, Romania",
			"articleRefs": [
				{
					"pageNumber": 10,
					"articleName": "SAGE - A Tool for Optimal Deployments in Kubernetes Clusters",
					"articleLocation": "pdfs/CloudCom2023-5izGlsJw6TI8iFevjODzl5/398200a010/398200a010.pdf"
				}
			]
		}
	]
}};